# Upstream / Reference Notes

This project is an independent Android implementation inspired by the public feature list and interaction model of aiko-chan-ai/DiscordBotClient.

V11 additionally follows public Android performance guidance around bitmap caching/downsampling and lightweight list binding, and public third-party Discord client patterns such as memory/disk image caches, viewport prioritization, rich custom emoji rendering, and mention rendering.
