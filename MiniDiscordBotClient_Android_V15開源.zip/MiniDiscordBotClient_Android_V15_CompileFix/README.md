# Mini Discord Bot Client Android V15

Android-native Discord bot client directionally inspired by the public feature set of aiko-chan-ai/DiscordBotClient.

## Build

Code on the Go / Gradle 9.6.1 / AGP 9.3.1 / compileSdk 35 / Java 17 source compatibility.

## V15 focus

- Native ListView message virtualization with row recycling.
- 3-second incremental message polling using `after`.
- 30-second reconciliation for edits/deletes without constantly rebuilding the UI.
- Scroll-position preservation while loading older history.
- Memory-first image loading, in-flight request coalescing, downsampling, and background disk persistence.
- Rich mention/custom emoji parsing cache.
- Reply, edit, delete, reaction toggle, pin/unpin, pinned messages, threads, search, attachments, stickers, polls, custom emoji creation, embeds/components display, announcement crosspost, typing indicator, user card, message links.
- Discord-style mobile layout with channel category collapse and long-name-safe text layout.

## Important scope

This is an Android-native implementation using the official Discord HTTP API. It is not a copy of the upstream source code or assets. Gateway-only functionality such as full live event delivery and arbitrary interactive component callbacks is intentionally kept separate from the REST-first core for stability.
