# V15 Mobile Optimized

- Replaced the chat ScrollView/LinearLayout message stack with a native ListView + recycled message rows.
- 3-second incremental polling now uses the Discord `after` message parameter instead of re-fetching 75 messages every cycle.
- Full message reconciliation runs roughly every 30 seconds to catch edits/deletes while preserving the user's scroll anchor.
- Older-message pagination preserves scroll position.
- Added parsed-rich-content caching for mentions/custom emoji rendering.
- Image loader now has a larger memory cache, more image workers, and a separate disk-write executor so disk persistence cannot block visible image loads.
- Added typing indicator API calls while composing.
- Added category collapse/expand in the channel list.
- Added message link copy, author card shortcut, pinned-message browser, pin/unpin, and announcement crosspost.
- Reaction chips now toggle add/remove based on the `me` flag.
- Kept existing reply/edit/delete, attachments, custom emoji creation, stickers, polls, threads, search, embeds, components, rich mentions and custom emoji rendering.
