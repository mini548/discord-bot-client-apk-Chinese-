# V12 Changelog

- Fixed V11 Java compilation error: ImageLoader requires Context.
- ImageLoader is initialized in Activity.onCreate with application context.
- Kept V11 rendering/cache behavior unchanged.
- Kept Discord mention/custom emoji rendering unchanged.
