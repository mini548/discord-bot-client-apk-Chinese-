# Changelog

## V11 Render & Performance Fix
- Fixed avatar/guild icon fallback being covered by an empty ImageView when CDN loading fails.
- Reworked image loading to use memory cache + disk cache + request coalescing + bitmap downsampling.
- Kept disk reads off the UI thread.
- Pre-warm up to 40 guild icons, 24 visible message avatars, and 80 guild custom emojis.
- Custom emoji rendering now uses Discord CDN PNG thumbnails for reliable first-frame rendering; animated emoji can be upgraded later without blocking the first render.
- Mention rendering remains rich: @user, @role, #channel, @everyone, and @here.
- Role/user/channel mention labels are normalized so JSON null values do not display as "null".
- Channel and category names no longer force single-line clipping; long names use smaller text and up to two lines.
- Chat header uses a marquee title so long channel names remain readable instead of being cut in half.
- Reduced per-image network timeouts and limited decoded bitmap sizes.

## Research notes
- Android recommends image caching and downsampling for bitmap-heavy UIs, and keeping RecyclerView binding lightweight.
- Public third-party Discord clients such as kind describe memory/disk image caching and viewport-prioritized loading; Concord documents rich rendering of custom emoji and mentions.
