package com.mini.discordbotclient.net;

import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class DiscordApi {
    public static final String BASE = "https://discord.com/api/v10";
    private final String token;
    private final Context context;

    public DiscordApi(Context context, String token) {
        this.context = context.getApplicationContext();
        this.token = token == null ? "" : token.trim();
    }

    public JSONObject me() throws Exception { return getObject("/users/@me"); }
    public JSONArray guilds() throws Exception { return getArray("/users/@me/guilds?limit=200"); }
    public JSONArray channels(String guildId) throws Exception { return getArray("/guilds/" + guildId + "/channels"); }
    public JSONArray guildEmojis(String guildId) throws Exception { return getArray("/guilds/" + guildId + "/emojis"); }
    public JSONArray guildStickers(String guildId) throws Exception { return getArray("/guilds/" + guildId + "/stickers"); }
    public JSONArray roles(String guildId) throws Exception { return getArray("/guilds/" + guildId + "/roles"); }

    public JSONArray messages(String channelId, String before, int limit) throws Exception {
        String path = "/channels/" + channelId + "/messages?limit=" + Math.max(1, Math.min(100, limit));
        if (before != null && !before.isEmpty()) path += "&before=" + URLEncoder.encode(before, "UTF-8");
        return getArray(path);
    }

    public JSONArray messagesAfter(String channelId, String after, int limit) throws Exception {
        String path = "/channels/" + channelId + "/messages?limit=" + Math.max(1, Math.min(100, limit));
        if (after != null && !after.isEmpty()) path += "&after=" + URLEncoder.encode(after, "UTF-8");
        return getArray(path);
    }

    public JSONObject sendMessage(String channelId, String content) throws Exception {
        JSONObject body = new JSONObject();
        body.put("content", content == null ? "" : content);
        return requestJson("POST", "/channels/" + channelId + "/messages", body.toString());
    }

    public JSONObject replyMessage(String channelId, String content, String replyMessageId) throws Exception {
        JSONObject body = new JSONObject();
        body.put("content", content == null ? "" : content);
        JSONObject ref = new JSONObject(); ref.put("message_id", replyMessageId); ref.put("channel_id", channelId);
        body.put("message_reference", ref);
        return requestJson("POST", "/channels/" + channelId + "/messages", body.toString());
    }

    public JSONObject sendFile(String channelId, String content, Uri uri, String fileName) throws Exception {
        return sendFile(channelId, content, uri, fileName, null);
    }

    public JSONObject sendFile(String channelId, String content, Uri uri, String fileName, String replyMessageId) throws Exception {
        if (uri == null) throw new IllegalArgumentException("No file selected");
        String boundary = "----MiniDiscord" + UUID.randomUUID().toString().replace("-", "");
        HttpURLConnection c = open("/channels/" + channelId + "/messages", "POST");
        c.setDoOutput(true);
        c.setChunkedStreamingMode(8192);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        JSONObject payload = new JSONObject();
        payload.put("content", content == null ? "" : content);
        if (replyMessageId != null && !replyMessageId.isEmpty()) { JSONObject ref = new JSONObject(); ref.put("message_id", replyMessageId); ref.put("channel_id", channelId); payload.put("message_reference", ref); }
        OutputStream raw = new BufferedOutputStream(c.getOutputStream(), 8192);
        writePart(raw, boundary, "payload_json", null, "application/json", payload.toString().getBytes(StandardCharsets.UTF_8));

        InputStream in = context.getContentResolver().openInputStream(uri);
        if (in == null) throw new FileNotFoundException("Cannot open selected file");
        String safeName = fileName == null || fileName.isEmpty() ? "attachment" : fileName.replace("\"", "_");
        String mime = context.getContentResolver().getType(uri);
        if (mime == null) mime = guessMime(safeName);

        raw.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        raw.write(("Content-Disposition: form-data; name=\"files[0]\"; filename=\"" + safeName + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        raw.write(("Content-Type: " + mime + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) raw.write(buffer, 0, n);
        in.close();
        raw.write("\r\n".getBytes(StandardCharsets.UTF_8));
        raw.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        raw.flush();
        raw.close();

        return readJsonObject(c);
    }

    public JSONObject editMessage(String channelId, String messageId, String content) throws Exception {
        JSONObject body = new JSONObject(); body.put("content", content == null ? "" : content);
        return requestJson("PATCH", "/channels/" + channelId + "/messages/" + messageId, body.toString());
    }

    public void deleteMessage(String channelId, String messageId) throws Exception { requestNoContent("DELETE", "/channels/" + channelId + "/messages/" + messageId); }
    public void addReaction(String channelId, String messageId, String emoji) throws Exception { requestNoContent("PUT", "/channels/" + channelId + "/messages/" + messageId + "/reactions/" + URLEncoder.encode(emoji, "UTF-8") + "/@me"); }
    public void removeReaction(String channelId, String messageId, String emoji) throws Exception { requestNoContent("DELETE", "/channels/" + channelId + "/messages/" + messageId + "/reactions/" + URLEncoder.encode(emoji, "UTF-8") + "/@me"); }
    public void pinMessage(String channelId, String messageId) throws Exception { requestNoContent("PUT", "/channels/" + channelId + "/messages/pins/" + messageId); }
    public void unpinMessage(String channelId, String messageId) throws Exception { requestNoContent("DELETE", "/channels/" + channelId + "/messages/pins/" + messageId); }
    public JSONArray pinnedMessages(String channelId) throws Exception {
        JSONObject o = getObject("/channels/" + channelId + "/messages/pins?limit=50");
        return o.optJSONArray("items") == null ? new JSONArray() : o.optJSONArray("items");
    }
    public JSONArray pins(String channelId) throws Exception { return getArray("/channels/" + channelId + "/pins"); }
    public void triggerTyping(String channelId) throws Exception { requestNoContent("POST", "/channels/" + channelId + "/typing"); }
    public JSONObject crosspostMessage(String channelId, String messageId) throws Exception { return requestJson("POST", "/channels/" + channelId + "/messages/" + messageId + "/crosspost", new JSONObject().toString()); }

    public JSONObject createThread(String channelId, String messageId, String name) throws Exception {
        JSONObject body = new JSONObject(); body.put("name", name); body.put("auto_archive_duration", 1440);
        return requestJson("POST", "/channels/" + channelId + "/messages/" + messageId + "/threads", body.toString());
    }

    public JSONObject sendSticker(String channelId, String stickerId) throws Exception {
        JSONObject body = new JSONObject(); JSONArray ids = new JSONArray(); ids.put(stickerId); body.put("sticker_ids", ids);
        return requestJson("POST", "/channels/" + channelId + "/messages", body.toString());
    }

    public JSONObject createPoll(String channelId, String question, String[] options) throws Exception {
        JSONObject poll = new JSONObject();
        poll.put("question", new JSONObject().put("text", question));
        JSONArray answers = new JSONArray();
        for (String option : options) { String x = option == null ? "" : option.trim(); if (!x.isEmpty()) answers.put(new JSONObject().put("poll_media", new JSONObject().put("text", x))); }
        poll.put("answers", answers); poll.put("duration", 24); poll.put("allow_multiselect", false); poll.put("layout_type", 1);
        JSONObject body = new JSONObject(); body.put("poll", poll);
        return requestJson("POST", "/channels/" + channelId + "/messages", body.toString());
    }

    public JSONArray searchMessages(String guildId, String channelId, String query) throws Exception {
        String path = "/guilds/" + guildId + "/messages/search?content=" + URLEncoder.encode(query, "UTF-8");
        if (channelId != null && !channelId.isEmpty()) path += "&channel_id=" + URLEncoder.encode(channelId, "UTF-8");
        JSONObject result = getObject(path);
        JSONArray arr = result.optJSONArray("messages");
        if (arr == null) return new JSONArray();
        JSONArray flat = new JSONArray();
        for (int i=0;i<arr.length();i++) { Object item=arr.opt(i); if(item instanceof JSONArray) { JSONArray group=(JSONArray)item; for(int j=0;j<group.length();j++) { Object msg=group.opt(j); if(msg instanceof JSONObject) flat.put(msg); } } else if(item instanceof JSONObject) flat.put(item); }
        return flat;
    }

    public JSONObject createGuildEmoji(String guildId, String name, String dataUri) throws Exception {
        JSONObject body = new JSONObject(); body.put("name", name); body.put("image", dataUri);
        return requestJson("POST", "/guilds/" + guildId + "/emojis", body.toString());
    }

    private void writePart(OutputStream out, String boundary, String name, String filename, String mime, byte[] bytes) throws Exception {
        out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        if (filename == null) {
            out.write(("Content-Disposition: form-data; name=\"" + name + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        } else {
            out.write(("Content-Disposition: form-data; name=\"" + name + "\"; filename=\"" + filename + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        }
        out.write(("Content-Type: " + mime + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(bytes);
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private String guessMime(String name) {
        String ext = MimeTypeMap.getFileExtensionFromUrl(name);
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return mime == null ? "application/octet-stream" : mime;
    }

    private JSONObject getObject(String path) throws Exception { return readJsonObject(open(path, "GET")); }
    private JSONArray getArray(String path) throws Exception { return readJsonArray(open(path, "GET")); }

    private void requestNoContent(String method, String path) throws Exception {
        HttpURLConnection c = open(path, method);
        int code = c.getResponseCode();
        String body = read(c);
        if (code < 200 || code >= 300) throw apiError(c, code, body);
        c.disconnect();
    }

    private JSONObject requestJson(String method, String path, String body) throws Exception {
        HttpURLConnection c = open(path, method);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(data.length);
        try (OutputStream out = new BufferedOutputStream(c.getOutputStream())) { out.write(data); }
        return readJsonObject(c);
    }

    private HttpURLConnection open(String path, String method) throws Exception {
        if (token.isEmpty()) throw new ApiException(401, "Token is empty");
        URL url = new URL(BASE + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setUseCaches(false);
        c.setRequestProperty("Authorization", "Bot " + token);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "MiniDiscordBotClient/2.0 (Android)");
        return c;
    }

    private JSONObject readJsonObject(HttpURLConnection c) throws Exception {
        String body = read(c);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw apiError(c, code, body);
        if (body == null || body.trim().isEmpty()) return new JSONObject();
        return new JSONObject(body);
    }

    private JSONArray readJsonArray(HttpURLConnection c) throws Exception {
        String body = read(c);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw apiError(c, code, body);
        return new JSONArray(body == null ? "[]" : body);
    }

    private String read(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream src = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        if (src == null) return "";
        try (InputStream in = new BufferedInputStream(src); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    private ApiException apiError(HttpURLConnection c, int code, String body) {
        String message = "Discord API error " + code;
        try {
            JSONObject o = new JSONObject(body == null ? "{}" : body);
            if (o.has("message")) message = o.optString("message", message);
        } catch (Exception ignored) { }
        if (code == 429) {
            String retry = c.getHeaderField("Retry-After");
            if (retry != null) message += " · Retry-After " + retry + "s";
        }
        if (code == 401) message = "Bot Token 無效或已過期（401）";
        if (code == 403) message = "Bot 沒有權限存取此資源（403）";
        if (code == 404) message = "頻道或資源不存在 / Bot 無法存取（404）";
        return new ApiException(code, message);
    }

    public static final class ApiException extends Exception {
        public final int status;
        public ApiException(int status, String message) { super(message); this.status = status; }
    }
}
