package com.mini.discordbotclient;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextUtils;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.StyleSpan;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.AbsListView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.mini.discordbotclient.net.DiscordApi;
import com.mini.discordbotclient.net.ImageLoader;
import com.mini.discordbotclient.security.SecureStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import android.util.Base64;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 7001;
    private static final int PICK_EMOJI_IMAGE = 7002;

    // Original mobile implementation inspired by the public architecture/features of
    // aiko-chan-ai/DiscordBotClient. No upstream source or assets are bundled here.
    private static final int BG = Color.rgb(11, 9, 30);
    private static final int RAIL = Color.rgb(7, 6, 18);
    private static final int PANEL = Color.rgb(20, 17, 43);
    private static final int PANEL_2 = Color.rgb(34, 28, 62);
    private static final int PANEL_3 = Color.rgb(45, 37, 79);
    private static final int ROW = Color.rgb(28, 24, 56);
    private static final int ROW_SEL = Color.rgb(56, 47, 91);
    private static final int TEXT = Color.rgb(247, 245, 255);
    private static final int MUTED = Color.rgb(186, 179, 207);
    private static final int SUBTLE = Color.rgb(132, 124, 157);
    private static final int ACCENT = Color.rgb(139, 122, 232);
    private static final int GREEN = Color.rgb(61, 214, 132);
    private static final int RED = Color.rgb(241, 92, 101);

    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
    private final AtomicBoolean refreshInFlight = new AtomicBoolean(false);
    private ImageLoader imageLoader;

    private SecureStore secureStore;
    private DiscordApi api;
    private JSONObject me;
    private String token;

    private JSONArray guilds = new JSONArray();
    private JSONArray channels = new JSONArray();
    private String currentGuildId;
    private String currentGuildName;
    private String currentChannelId;
    private String currentChannelName;
    private String oldestMessageId;
    private String latestMessageId;

    private LinearLayout root;
    private LinearLayout rail;
    private LinearLayout channelPane;
    private LinearLayout channelRows;
    private ListView messageList;
    private ChatAdapter chatAdapter;
    private final List<JSONObject> messageItems = new ArrayList<>();
    private String lastMessageFingerprint = "";
    private long lastFullSyncAt = 0L;
    private TextView topTitle;
    private TextView chatChannelTitle;
    private TextView chatUnreadBadge;
    private ImageButton chatSearchButton;
    private TextView emojiButton;
    private TextView statusText;
    private EditText channelSearch;
    private EditText composer;
    private TextView composerHint;
    private ImageButton sendButton;
    private ImageButton attachButton;
    private ProgressBar topProgress;
    private TextView userName;
    private TextView userTag;
    private ImageView userAvatar;

    private final Map<String, JSONObject> channelById = new LinkedHashMap<>();
    private final Map<String, JSONObject> emojiById = new LinkedHashMap<>();
    private JSONArray guildEmojis = new JSONArray();
    private JSONArray guildStickers = new JSONArray();
    private final Map<String, String> roleNameById = new LinkedHashMap<>();
    private final Map<String, Integer> roleColorById = new LinkedHashMap<>();
    private final Map<String, List<RichPart>> richPartsCache = new HashMap<>();
    private static final Pattern DISCORD_RICH_TOKEN = Pattern.compile("<(a)?:([A-Za-z0-9_~]+):(\\d+)>|<@!?([\\d]+)>|<@&([\\d]+)>|<#([\\d]+)>|@(everyone|here)");
    private String replyToMessageId;
    private String editingMessageId;
    private String editingOriginalContent;
    private boolean loadingOlder = false;
    private String channelFilter = "";
    private final Map<String, Boolean> categoryCollapsed = new HashMap<>();
    private boolean loginBusy = false;
    private boolean chatBusy = false;
    private boolean navigationVisible = true;
    private boolean darkMode = true;
    private ScheduledFuture<?> pollFuture;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView tv(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private TextView bold(String value, float size) {
        TextView t = tv(value, size, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private StateListDrawable pressable(int normal, int pressed, float radius) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, bg(pressed, radius));
        states.addState(new int[]{}, bg(normal, radius));
        return states;
    }

    private ImageButton iconButton(String glyph, int size, int background) {
        ImageButton b = new ImageButton(this);
        b.setImageDrawable(new TextIconDrawable(glyph, TEXT, dp(size * .45f)));
        b.setBackground(bg(background, 16));
        b.setPadding(0, 0, 0, 0);
        b.setContentDescription(glyph);
        return b;
    }

    // Tiny drawable used instead of bundling icon libraries. Keeps the UI light/offline-friendly.
    private static final class TextIconDrawable extends android.graphics.drawable.Drawable {
        private final String text;
        private final int color;
        private final float size;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        TextIconDrawable(String text, int color, float size) {
            this.text = text; this.color = color; this.size = size;
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        }
        @Override public void draw(android.graphics.Canvas canvas) {
            paint.setColor(color); paint.setTextSize(size); paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            android.graphics.Paint.FontMetrics fm = paint.getFontMetrics();
            float y = getBounds().centerY() - (fm.ascent + fm.descent) / 2f;
            canvas.drawText(text, getBounds().centerX(), y, paint);
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(RAIL);
        w.setNavigationBarColor(RAIL);
        installCrashReporter();
        try {
            secureStore = new SecureStore(this);
            imageLoader = new ImageLoader(getApplicationContext());
            showLogin();
        } catch (Throwable t) {
            fatal(t);
        }
    }

    private void installCrashReporter() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                getSharedPreferences("diagnostics", MODE_PRIVATE).edit()
                        .putString("last_crash", thread.getName() + "\n" + sw)
                        .apply();
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    private void fatal(Throwable t) {
        LinearLayout box = column(); box.setGravity(Gravity.CENTER); box.setPadding(dp(24), dp(24), dp(24), dp(24)); box.setBackgroundColor(BG);
        TextView title = bold("Mini Discord Bot Client 啟動失敗", 22); title.setGravity(Gravity.CENTER); box.addView(title, new LinearLayout.LayoutParams(-1, dp(56)));
        TextView detail = tv(t.getClass().getSimpleName() + "\n" + String.valueOf(t.getMessage()), 13, MUTED); detail.setGravity(Gravity.CENTER); box.addView(detail, new LinearLayout.LayoutParams(-1, -2));
        setContentView(box);
    }

    // ---------------------------------------------------------------------
    // Login
    // ---------------------------------------------------------------------
    private void showLogin() {
        stopPolling();
        LinearLayout page = column(); page.setBackgroundColor(BG); page.setPadding(dp(18), dp(28), dp(18), dp(20));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(page);
        setContentView(scroll);

        Space top = new Space(this); page.addView(top, new LinearLayout.LayoutParams(1, dp(26)));

        LinearLayout card = column(); card.setPadding(dp(22), dp(22), dp(22), dp(22)); card.setBackground(bg(PANEL, 28));
        page.addView(card, new LinearLayout.LayoutParams(-1, -2));

        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.ic_bot); logo.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(92), dp(92)); logoLp.gravity = Gravity.CENTER_HORIZONTAL; card.addView(logo, logoLp);

        TextView title = bold("Mini Discord Bot Client", 24); title.setGravity(Gravity.CENTER); card.addView(title, lp(-1, 40));
        TextView sub = tv("Mobile 原生 Client · Bot Token · Guild → Channel → Message", 13, MUTED); sub.setGravity(Gravity.CENTER); sub.setPadding(0, 0, 0, dp(14)); card.addView(sub, lp(-1, -2));

        TextView security = tv("Token 只儲存在本機 Android Keystore；不會送到第三方伺服器。", 12, SUBTLE); security.setGravity(Gravity.CENTER); security.setPadding(dp(6), 0, dp(6), dp(14)); card.addView(security, lp(-1, -2));

        LinearLayout tokenBox = row(); tokenBox.setPadding(dp(12), 0, dp(6), 0); tokenBox.setBackground(bg(PANEL_2, 16));
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("貼上 Bot Token"); input.setHintTextColor(SUBTLE); input.setTextColor(TEXT); input.setTextSize(15); input.setPadding(0, 0, 0, 0); input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenBox.addView(input, new LinearLayout.LayoutParams(0, dp(54), 1));
        TextView eye = tv("顯示", 12, MUTED); eye.setGravity(Gravity.CENTER); eye.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 12)); tokenBox.addView(eye, new LinearLayout.LayoutParams(dp(58), dp(40)));
        eye.setOnClickListener(v -> {
            boolean hidden = (input.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            if (hidden) {
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                eye.setText("隱藏");
            } else {
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                eye.setText("顯示");
            }
            input.setSelection(input.length());
        });
        card.addView(tokenBox, lp(-1, 54));

        TextView hint = tv("支援直接貼上 Token，也會自動移除前面的「Bot 」前綴。", 12, SUBTLE); hint.setPadding(dp(4), dp(8), dp(4), dp(2)); card.addView(hint, lp(-1, -2));

        LinearLayout actions = row(); actions.setPadding(0, dp(16), 0, 0);
        TextView login = bold("登入", 15); login.setGravity(Gravity.CENTER); login.setBackground(pressable(ACCENT, Color.rgb(115, 99, 203), 16)); actions.addView(login, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView clear = tv("清除", 14, TEXT); clear.setGravity(Gravity.CENTER); clear.setBackground(pressable(PANEL_2, PANEL_3, 16)); LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(dp(86), dp(52)); clearLp.setMargins(dp(10), 0, 0, 0); actions.addView(clear, clearLp);
        card.addView(actions);

        String saved = null;
        try { saved = secureStore.loadToken(); } catch (Exception ignored) { }
        if (saved != null && !saved.trim().isEmpty()) {
            input.setText(saved);
            TextView savedLabel = tv("已找到本機保存的 Token · 需要重新驗證才會登入", 12, GREEN); savedLabel.setPadding(dp(4), dp(14), dp(4), 0); card.addView(savedLabel, lp(-1, -2));
        }

        TextView disclaimer = tv("第三方 Client，不是 Discord 官方 App。請只使用你自己有權管理的 Bot Token。", 11, SUBTLE); disclaimer.setGravity(Gravity.CENTER); disclaimer.setPadding(dp(6), dp(24), dp(6), dp(8)); page.addView(disclaimer, lp(-1, -2));

        clear.setOnClickListener(v -> { input.setText(""); secureStore.clear(); toast("已清除保存的 Token"); });
        login.setOnClickListener(v -> attemptLogin(input, login));
    }

    private void attemptLogin(EditText input, TextView button) {
        if (loginBusy) return;
        String raw = input.getText().toString().trim();
        if (raw.isEmpty()) { toast("請貼上 Bot Token"); return; }
        String clean = raw.replaceFirst("(?i)^Bot\\s+", "").trim();
        if (clean.isEmpty()) { toast("Token 格式不正確"); return; }
        loginBusy = true; button.setText("驗證中…"); button.setEnabled(false);
        io.execute(() -> {
            try {
                DiscordApi candidate = new DiscordApi(this, clean);
                JSONObject identity = candidate.me();
                secureStore.saveToken(clean);
                runOnUiThread(() -> {
                    loginBusy = false;
                    button.setEnabled(true);
                    button.setText("登入");
                    token = clean; api = candidate; me = identity;
                    showWorkspace();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    loginBusy = false; button.setEnabled(true); button.setText("登入");
                    toast("登入失敗：" + friendlyError(t));
                });
            }
        });
    }

    // ---------------------------------------------------------------------
    // Workspace / navigation
    // ---------------------------------------------------------------------
    private void showWorkspace() {
        navigationVisible = true;
        buildNavigation();
        loadGuilds();
    }

    private void buildNavigation() {
        root = column(); root.setBackgroundColor(BG);
        root.setPadding(0, dp(6), 0, 0);
        setContentView(root);

        LinearLayout content = row(); root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildServerRail(content);

        channelPane = column(); channelPane.setBackgroundColor(PANEL); content.addView(channelPane, new LinearLayout.LayoutParams(0, -1, 1));
        buildChannelPane();
    }

    private void buildServerRail(LinearLayout parent) {
        rail = column(); rail.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL); rail.setBackgroundColor(RAIL); rail.setPadding(dp(8), dp(6), dp(8), dp(8));
        parent.addView(rail, new LinearLayout.LayoutParams(dp(78), -1));

        TextView home = bold("M", 18); home.setGravity(Gravity.CENTER); home.setBackground(pressable(PANEL_3, PANEL_2, 20)); home.setContentDescription("首頁"); rail.addView(home, lp(54, 54));
        home.setOnClickListener(v -> { currentGuildId = null; currentGuildName = null; currentChannelId = null; currentChannelName = null; buildChannelPane(); });

        Space gap = new Space(this); rail.addView(gap, lp(1, 10));
        for (int i = 0; i < guilds.length(); i++) {
            JSONObject g = guilds.optJSONObject(i); if (g == null) continue;
            addGuildIcon(g);
        }
        Space bottom = new Space(this); rail.addView(bottom, new LinearLayout.LayoutParams(1, 0, 1));
        TextView settings = tv("⚙", 21, TEXT); settings.setGravity(Gravity.CENTER); settings.setBackground(pressable(PANEL_2, PANEL_3, 18)); rail.addView(settings, lp(54, 54));
        settings.setOnClickListener(v -> showSettings());
    }

    private void addGuildIcon(JSONObject guild) {
        String id = guild.optString("id", ""); String name = guild.optString("name", "Server"); String icon = guild.optString("icon", "");
        String url = icon.isEmpty() ? "" : "https://cdn.discordapp.com/icons/" + id + "/" + icon + ".png?size=96";

        FrameLayoutWrap holder = new FrameLayoutWrap(this); holder.setPadding(0, dp(4), 0, dp(4));
        ImageView image = new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackground(bg(PANEL_2, 18)); image.setClipToOutline(true); image.setContentDescription(name);
        TextView fallback = tv(firstLetter(name), 18, TEXT); fallback.setGravity(Gravity.CENTER); fallback.setBackground(bg(guildColor(id), 18));
        holder.add(fallback, lp(54, 54)); holder.add(image, lp(54, 54));
        if (!url.isEmpty()) imageLoader.load(url, image, null, io);
        holder.setOnClickListener(v -> selectGuild(guild));
        rail.addView(holder, lp(-1, 62));
        holder.setSelected(id.equals(currentGuildId));
    }

    private int guildColor(String id) {
        int[] colors = {Color.rgb(89, 74, 150), Color.rgb(70, 105, 155), Color.rgb(152, 79, 115), Color.rgb(62, 128, 115), Color.rgb(121, 85, 139)};
        int idx = Math.abs(id.hashCode()) % colors.length;
        return colors[idx];
    }

    private void buildChannelPane() {
        channelPane.removeAllViews();
        channelPane.setClipChildren(false);
        channelPane.setClipToPadding(false);
        channelPane.setPadding(dp(14), dp(10), dp(10), dp(10));

        LinearLayout header = row();
        TextView name = bold(currentGuildName == null ? "選擇伺服器" : currentGuildName, 20); header.addView(name, new LinearLayout.LayoutParams(0, dp(50), 1));
        TextView refresh = tv("↻", 22, TEXT); refresh.setGravity(Gravity.CENTER); refresh.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 14)); header.addView(refresh, lp(46, 46));
        refresh.setOnClickListener(v -> { if (currentGuildId == null) loadGuilds(); else loadChannels(currentGuildId, true); });
        channelPane.addView(header, lp(-1, 52));

        LinearLayout searchBox = row(); searchBox.setPadding(dp(12), 0, dp(10), 0); searchBox.setBackground(bg(PANEL_2, 14));
        TextView searchIcon = tv("⌕", 20, MUTED); searchBox.addView(searchIcon, lp(26, 46));
        channelSearch = new EditText(this); channelSearch.setSingleLine(true); channelSearch.setHint("搜尋頻道"); channelSearch.setHintTextColor(SUBTLE); channelSearch.setTextColor(TEXT); channelSearch.setTextSize(14); channelSearch.setBackgroundColor(Color.TRANSPARENT); channelSearch.setPadding(0, 0, 0, 0); searchBox.addView(channelSearch, new LinearLayout.LayoutParams(0, dp(46), 1));
        channelPane.addView(searchBox, lp(-1, 46));
        channelSearch.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s, int a, int b, int c) {} public void onTextChanged(CharSequence s, int a, int b, int c) { channelFilter = s.toString().trim().toLowerCase(Locale.ROOT); renderChannels(); } public void afterTextChanged(Editable e) {} });

        if (currentGuildId == null) {
            TextView empty = tv("從左側選一個伺服器\n\n介面刻意維持手機版的「伺服器列 → 頻道列 → 聊天」流程，避免三欄擠在一起。", 14, MUTED); empty.setGravity(Gravity.CENTER); channelPane.addView(empty, new LinearLayout.LayoutParams(-1, 0, 1));
        } else {
            ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); channelRows = column(); channelRows.setPadding(0, dp(12), 0, dp(12)); channelRows.setClipChildren(false); channelRows.setClipToPadding(false); scroll.setClipChildren(false); scroll.setClipToPadding(false); scroll.addView(channelRows); channelPane.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
            renderChannels();
        }

        LinearLayout account = row(); account.setPadding(dp(10), dp(8), dp(8), dp(8)); account.setBackground(bg(RAIL, 18));
        userAvatar = new ImageView(this); userAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP); userAvatar.setBackground(bg(PANEL_2, 18)); userAvatar.setClipToOutline(true); account.addView(userAvatar, lp(46, 46));
        LinearLayout labels = column(); labels.setPadding(dp(10), 0, dp(4), 0); userName = bold(me == null ? "Bot" : safeDisplayName(me), 14); userTag = tv("Bot · 已登入", 11, GREEN); labels.addView(userName, lp(-1, 24)); labels.addView(userTag, lp(-1, 18)); account.addView(labels, new LinearLayout.LayoutParams(0, 50, 1));
        TextView more = tv("⋯", 24, TEXT); more.setGravity(Gravity.CENTER); more.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 12)); account.addView(more, lp(42, 42));
        more.setOnClickListener(v -> showSettings());
        channelPane.addView(account, lp(-1, 66));
        loadMeAvatar();
    }

    private String normalizeChannelName(String value) {
        if (value == null) return "channel";
        String s = value.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
        s = s.replaceAll("\\s+", " ");
        return s.isEmpty() ? "channel" : s;
    }

    private void renderChannels() {
        if (channelRows == null) return;
        channelRows.removeAllViews();
        if (channels.length() == 0) { TextView t = tv("沒有可見頻道", 14, MUTED); t.setPadding(dp(8), dp(18), 0, 0); channelRows.addView(t); return; }

        List<JSONObject> all = new ArrayList<>();
        for (int i = 0; i < channels.length(); i++) { JSONObject c = channels.optJSONObject(i); if (c != null) all.add(c); }
        Collections.sort(all, Comparator.comparingInt(o -> o.optInt("position", 0)));

        Map<String, List<JSONObject>> groups = new LinkedHashMap<>();
        List<JSONObject> uncategorized = new ArrayList<>();
        for (JSONObject c : all) {
            String parent = c.optString("parent_id", "");
            String name = c.optString("name", "").toLowerCase(Locale.ROOT);
            if (!channelFilter.isEmpty() && !name.contains(channelFilter)) continue;
            if (c.optInt("type", 0) == 4) { groups.put(c.optString("id", ""), new ArrayList<>()); }
            else if (parent.isEmpty()) uncategorized.add(c);
        }
        for (JSONObject c : all) {
            String parent = c.optString("parent_id", "");
            if (!parent.isEmpty() && groups.containsKey(parent)) {
                if (!channelFilter.isEmpty() && !c.optString("name", "").toLowerCase(Locale.ROOT).contains(channelFilter)) continue;
                groups.get(parent).add(c);
            }
        }

        channelById.clear();
        if (!uncategorized.isEmpty()) {
            sectionHeader("頻道", null);
            for (JSONObject c : uncategorized) addChannelRow(c, false);
        }
        for (JSONObject category : all) {
            if (category.optInt("type", -1) != 4) continue;
            String catId = category.optString("id", "");
            List<JSONObject> children = groups.get(catId);
            if (children == null || children.isEmpty()) continue;
            sectionHeader(category.optString("name", "類別"), category);
            if (categoryCollapsed.getOrDefault(catId, false)) continue;
            for (JSONObject c : children) addChannelRow(c, true);
        }
    }

    private void sectionHeader(String title, JSONObject category) {
        LinearLayout h = row();
        h.setPadding(dp(6), dp(10), dp(4), dp(4));
        h.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        h.setClipChildren(false);

        TextView caret = tv("⌄", 15, SUBTLE);
        caret.setGravity(Gravity.CENTER);
        h.addView(caret, lp(24, 30));

        String normalized = normalizeChannelName(title);
        TextView t = bold(normalized, 12);
        t.setTextColor(MUTED);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        t.setSingleLine(false);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setHorizontallyScrolling(false);
        t.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setPadding(0, 0, dp(4), 0);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        t.bringToFront();
        h.setOnLongClickListener(v -> { toast(title); return true; });

        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(2), 0, dp(2));
        channelRows.addView(h, hp);
    }

    private void addChannelRow(JSONObject channel, boolean child) {
        String id = channel.optString("id", "");
        String name = normalizeChannelName(channel.optString("name", "channel"));
        int type = channel.optInt("type", 0);
        channelById.put(id, channel);

        String icon = type == 2 || type == 13 ? "♟" : "#";
        boolean selected = id.equals(currentChannelId);

        LinearLayout r = row();
        r.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        r.setPadding(child ? dp(18) : dp(8), dp(5), dp(6), dp(5));
        r.setBackground(pressable(selected ? ROW_SEL : Color.TRANSPARENT, PANEL_3, 12));
        r.setClipChildren(false);

        TextView ic = tv(icon, 18, selected ? TEXT : MUTED);
        ic.setGravity(Gravity.CENTER);
        ic.setIncludeFontPadding(true);
        r.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(42)));

        TextView label = tv(name, 15, selected ? TEXT : MUTED);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setIncludeFontPadding(true);
        label.setTypeface(Typeface.create("sans-serif", selected ? Typeface.BOLD : Typeface.NORMAL));
        label.setSingleLine(false);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setHorizontallyScrolling(false);
        label.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
        label.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        label.setContentDescription("頻道：" + name);
        label.setOnLongClickListener(v -> { toast(name); return true; });
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, -2, 1);
        textLp.setMargins(dp(2), 0, dp(2), 0);
        r.addView(label, textLp);

        if (type == 2 || type == 13) {
            TextView voice = tv("⋯", 15, SUBTLE);
            voice.setGravity(Gravity.CENTER);
            r.addView(voice, new LinearLayout.LayoutParams(dp(24), dp(42)));
        }

        // Keep the text layer visually above the decorative/background children.
        label.bringToFront();
        ic.bringToFront();
        r.setOnClickListener(v -> selectChannel(channel));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(0, dp(2), 0, dp(2));
        channelRows.addView(r, rp);
    }

    private void selectGuild(JSONObject guild) {
        currentGuildId = guild.optString("id", ""); currentGuildName = guild.optString("name", "伺服器"); currentChannelId = null; currentChannelName = null; latestMessageId = null;
        buildNavigation();
        loadChannels(currentGuildId, false);
        loadGuildExtras(currentGuildId);
    }

    private void selectChannel(JSONObject channel) {
        int channelType = channel.optInt("type", 0);
        if (!(channelType == 0 || channelType == 5 || channelType == 10 || channelType == 11 || channelType == 12 || channelType == 13 || channelType == 15)) {
            toast("此頻道類型目前無法在聊天頁顯示"); return;
        }
        currentChannelId = channel.optString("id", ""); currentChannelName = channel.optString("name", "channel"); latestMessageId = null; lastFullSyncAt = 0L;
        showChat();
        loadMessages(true, null);
        startPolling();
    }

    // ---------------------------------------------------------------------
    // Chat
    // ---------------------------------------------------------------------
    private void showChat() {
        navigationVisible = false;
        stopPolling();
        root = column(); root.setBackgroundColor(BG); setContentView(root);

        LinearLayout header = row();
        header.setPadding(dp(8), dp(6), dp(8), dp(6));
        header.setBackgroundColor(RAIL);

        TextView back = tv("‹", 34, TEXT);
        back.setGravity(Gravity.CENTER);
        back.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 16));
        header.addView(back, lp(42, 46));
        back.setOnClickListener(v -> buildNavigation());

        TextView channelIcon = tv("#", 22, MUTED);
        channelIcon.setGravity(Gravity.CENTER);
        header.addView(channelIcon, lp(34, 46));

        LinearLayout titleBox = column();
        titleBox.setClipChildren(false);
        titleBox.setClipToPadding(false);
        titleBox.setPadding(dp(2), 0, 0, 0);
        chatChannelTitle = bold(normalizeChannelName(currentChannelName == null ? "頻道" : currentChannelName), 17);
        chatChannelTitle.setSingleLine(true);
        chatChannelTitle.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        chatChannelTitle.setMarqueeRepeatLimit(-1);
        chatChannelTitle.setSelected(true);
        chatChannelTitle.setIncludeFontPadding(false);
        chatChannelTitle.setGravity(Gravity.CENTER_VERTICAL);
        chatChannelTitle.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        chatChannelTitle.setPadding(0, 0, dp(10), 0);
        titleBox.addView(chatChannelTitle, new LinearLayout.LayoutParams(-1, 30));
        statusText = tv("正在載入…", 10, MUTED);
        titleBox.addView(statusText, lp(-1, 18));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, 52, 1));

        TextView details = tv("⌄", 21, MUTED);
        details.setGravity(Gravity.CENTER);
        details.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 14));
        header.addView(details, lp(38, 46));
        details.setOnClickListener(v -> showChannelInfo());

        chatSearchButton = iconButton("⌕", 40, Color.TRANSPARENT);
        header.addView(chatSearchButton, lp(42, 46));
        chatSearchButton.setOnClickListener(v -> showMessageSearch());
        root.addView(header, lp(-1, 58));

        messageList = new ListView(this);
        messageList.setDivider(null);
        messageList.setDividerHeight(0);
        messageList.setBackgroundColor(BG);
        messageList.setClipToPadding(false);
        messageList.setPadding(0, dp(8), 0, dp(12));
        messageList.setCacheColorHint(Color.TRANSPARENT);
        messageList.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
        chatAdapter = new ChatAdapter();
        messageList.setAdapter(chatAdapter);
        root.addView(messageList, new LinearLayout.LayoutParams(-1, 0, 1));
        messageList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView view, int scrollState) {}
            @Override public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (firstVisibleItem <= 1 && oldestMessageId != null && !loadingOlder && messageItems.size() >= 20) {
                    loadingOlder = true;
                    loadMessages(false, oldestMessageId);
                }
                int last = firstVisibleItem + visibleItemCount;
                chatUnreadBadge = null;
                if (last >= totalItemCount - 1) {
                    // User is at the bottom; incremental updates can auto-follow.
                }
            }
        });

        LinearLayout composerBar = row();
        composerBar.setPadding(dp(8), dp(8), dp(8), dp(8));
        composerBar.setBackground(bg(PANEL, 20));
        attachButton = iconButton("＋", 42, PANEL_2);
        composerBar.addView(attachButton, lp(44, 44));
        attachButton.setOnClickListener(v -> showComposerMenu());

        composer = new EditText(this);
        composer.setHint("傳訊息到 #" + normalizeChannelName(currentChannelName));
        composer.setHintTextColor(SUBTLE);
        composer.setTextColor(TEXT);
        composer.setTextSize(15);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setSingleLine(false);
        composer.setMaxLines(5);
        composer.setBackground(bg(PANEL_2, 18));
        composer.setPadding(dp(13), dp(5), dp(10), dp(5));
        composerBar.addView(composer, new LinearLayout.LayoutParams(0, 46, 1));

        emojiButton = tv("☺", 24, MUTED);
        emojiButton.setGravity(Gravity.CENTER);
        emojiButton.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 14));
        composerBar.addView(emojiButton, lp(42, 44));
        emojiButton.setOnClickListener(v -> showEmojiPicker());

        sendButton = iconButton("➤", 42, ACCENT);
        composerBar.addView(sendButton, lp(44, 44));
        sendButton.setOnClickListener(v -> sendCurrentMessage(null));
        root.addView(composerBar, lp(-1, 62));

        composer.setOnEditorActionListener((v, actionId, event) -> { sendCurrentMessage(null); return true; });
        composer.addTextChangedListener(new TextWatcher() {
            private long lastTyping = 0;
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                if (s.length() == 0 || currentChannelId == null) return;
                long now = System.currentTimeMillis();
                if (now - lastTyping < 7000) return;
                lastTyping = now;
                io.execute(() -> { try { api.triggerTyping(currentChannelId); } catch (Throwable ignored) {} });
            }
            public void afterTextChanged(Editable e) {}
        });

        messageItems.clear();
        lastMessageFingerprint = "";
    }

    private void renderMessages(JSONArray list, boolean replace) {
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < list.length(); i++) { JSONObject m = list.optJSONObject(i); if (m != null) items.add(m); }
        Collections.reverse(items);
        warmMessageAvatars(items);

        if (replace) {
            String fingerprint = fingerprint(items);
            if (!fingerprint.isEmpty() && fingerprint.equals(lastMessageFingerprint) && !messageItems.isEmpty()) return;

            boolean hadMessages = !messageItems.isEmpty();
            boolean atBottom = !hadMessages || messageList == null || messageList.getLastVisiblePosition() >= messageItems.size() - 2;
            String anchorId = null;
            int anchorTop = 0;
            if (hadMessages && messageList != null && messageList.getFirstVisiblePosition() < messageItems.size()) {
                int first = messageList.getFirstVisiblePosition();
                anchorId = messageItems.get(first).optString("id", null);
                View firstChild = messageList.getChildAt(0);
                anchorTop = firstChild == null ? 0 : firstChild.getTop();
            }

            messageItems.clear();
            messageItems.addAll(items);
            lastMessageFingerprint = fingerprint;
            lastFullSyncAt = System.currentTimeMillis();
            if (!items.isEmpty()) {
                latestMessageId = items.get(items.size() - 1).optString("id", null);
                oldestMessageId = items.get(0).optString("id", null);
            } else {
                latestMessageId = null;
                oldestMessageId = null;
            }
            if (chatAdapter != null) chatAdapter.notifyDataSetChanged();

            final String finalAnchorId = anchorId;
            final int finalAnchorTop = anchorTop;
            if (messageList != null) messageList.post(() -> {
                if (!hadMessages || atBottom || finalAnchorId == null) {
                    if (!messageItems.isEmpty()) messageList.setSelection(messageItems.size() - 1);
                    return;
                }
                int index = 0;
                for (int i = 0; i < messageItems.size(); i++) {
                    if (finalAnchorId.equals(messageItems.get(i).optString("id", ""))) { index = i; break; }
                }
                messageList.setSelectionFromTop(index, finalAnchorTop);
            });
            return;
        }

        if (items.isEmpty()) { loadingOlder = false; return; }
        int firstVisible = messageList == null ? 0 : messageList.getFirstVisiblePosition();
        View firstChild = messageList == null ? null : messageList.getChildAt(0);
        int top = firstChild == null ? 0 : firstChild.getTop();
        Set<String> existing = new HashSet<>();
        for (JSONObject m : messageItems) existing.add(m.optString("id", ""));
        List<JSONObject> freshOlder = new ArrayList<>();
        for (JSONObject m : items) {
            String id = m.optString("id", "");
            if (!existing.contains(id)) { freshOlder.add(m); existing.add(id); }
        }
        int added = freshOlder.size();
        if (added > 0) messageItems.addAll(0, freshOlder);
        if (!messageItems.isEmpty()) oldestMessageId = messageItems.get(0).optString("id", oldestMessageId);
        if (chatAdapter != null) chatAdapter.notifyDataSetChanged();
        if (added > 0 && messageList != null) { final int offset = added; messageList.post(() -> messageList.setSelectionFromTop(firstVisible + offset, top)); }
        loadingOlder = false;
    }

    private String fingerprint(List<JSONObject> items) {
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, items.size() - 75);
        for (int i = start; i < items.size(); i++) {
            JSONObject m = items.get(i);
            sb.append(m.optString("id", "")).append('|').append(m.optString("content", ""));
            sb.append('|').append(m.optString("edited_timestamp", ""));
            sb.append(';');
        }
        return sb.toString();
    }

    private View buildMessageRow(JSONObject m) { return buildMessageRowInto(null, m); }

    private LinearLayout buildMessageRowInto(LinearLayout recycled, JSONObject m) {
        LinearLayout outer = recycled == null ? row() : recycled;
        outer.removeAllViews();
        outer.setOrientation(LinearLayout.HORIZONTAL);
        outer.setGravity(Gravity.TOP);
        outer.setPadding(dp(6), dp(8), dp(6), dp(8));
        outer.setBackground(pressable(Color.TRANSPARENT, Color.rgb(18, 16, 39), 12));

        JSONObject author = m.optJSONObject("author"); if (author == null) author = new JSONObject();
        String username = author.optString("global_name", author.optString("username", "Bot User"));
        String userId = author.optString("id", "0"); String avatarHash = author.optString("avatar", "");
        String timestamp = m.optString("timestamp", ""); String content = m.optString("content", "");
        boolean isBot = author.optBoolean("bot", false);
        final JSONObject clickAuthor = author;
        String avatarUrl = avatarUrl(userId, avatarHash);

        FrameLayoutWrap avatarWrap = new FrameLayoutWrap(this);
        TextView avatarFallback = tv(firstLetter(username), 15, TEXT); avatarFallback.setGravity(Gravity.CENTER); avatarFallback.setBackground(bg(guildColor(userId), 18));
        ImageView avatar = new ImageView(this); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(bg(PANEL_2, 18)); avatar.setClipToOutline(true);
        avatarWrap.add(avatarFallback, lp(48, 48)); avatarWrap.add(avatar, lp(48, 48)); outer.addView(avatarWrap, lp(48, 48));
        if (!avatarUrl.isEmpty()) imageLoader.load(avatarUrl, avatar, null, io);
        avatarWrap.setOnClickListener(v -> showUserCard(clickAuthor));

        LinearLayout body = column(); body.setClipChildren(false); body.setClipToPadding(false); body.setPadding(dp(11), 0, dp(4), 0);
        LinearLayout meta = row();
        TextView name = bold(username, 15); name.setTextColor(guildColor(userId)); meta.addView(name, new LinearLayout.LayoutParams(-2, dp(24)));
        if (isBot) {
            TextView bot = tv(" BOT ", 9, TEXT); bot.setGravity(Gravity.CENTER); bot.setBackground(bg(ACCENT, 7));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, dp(18)); bp.setMargins(dp(6), dp(2), 0, 0); meta.addView(bot, bp);
        }
        String editedLabel = m.optString("edited_timestamp", "").isEmpty() ? "" : " · 已編輯";
        TextView time = tv(formatTime(timestamp) + editedLabel, 10, SUBTLE); time.setPadding(dp(8), 0, 0, 0); meta.addView(time, new LinearLayout.LayoutParams(0, dp(24), 1));
        body.addView(meta, lp(-1, 24));
        name.setOnClickListener(v -> showUserCard(clickAuthor));

        String referenced = "";
        JSONObject ref = m.optJSONObject("message_reference");
        if (ref != null && ref.has("message_id")) referenced = "↪ 回覆訊息";
        if (!referenced.isEmpty()) {
            JSONObject refMsg = m.optJSONObject("referenced_message");
            String preview = refMsg == null ? "↪ 回覆訊息" : "↪ " + safeDisplayName(refMsg.optJSONObject("author")) + ": " + refMsg.optString("content", "(附件)");
            TextView r = tv(preview, 10, MUTED); r.setMaxLines(2); r.setEllipsize(TextUtils.TruncateAt.END); r.setPadding(0, 0, 0, dp(3)); body.addView(r, lp(-1, -2));
        }

        if (!content.isEmpty()) {
            TextView msg = tv("", 15, TEXT); msg.setLineSpacing(dp(1), 1.06f); msg.setTextIsSelectable(false); msg.setIncludeFontPadding(true); msg.setSingleLine(false); msg.setHorizontallyScrolling(false); msg.setMaxLines(Integer.MAX_VALUE); msg.setEllipsize(null); msg.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
            msg.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); msg.setTag("msg-rich-" + m.optString("id", ""));
            renderDiscordContent(msg, content, m); body.addView(msg, lp(-1, -2));
        }

        JSONArray embeds = m.optJSONArray("embeds");
        if (embeds != null && embeds.length() > 0) {
            for (int i = 0; i < embeds.length(); i++) {
                JSONObject e = embeds.optJSONObject(i); if (e == null) continue;
                LinearLayout eb = column(); eb.setPadding(dp(10), dp(8), dp(10), dp(8)); eb.setBackground(bg(PANEL_2, 13));
                String et = e.optString("title", e.optString("description", "Embed"));
                eb.addView(tv(et, 13, TEXT), lp(-1, -2));
                String eu = e.optString("url", ""); if (!eu.isEmpty()) { TextView link = tv(eu, 10, ACCENT); eb.addView(link, lp(-1, -2)); link.setOnClickListener(v -> openUrl(eu)); }
                LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2); ep.setMargins(0, dp(8), 0, 0); body.addView(eb, ep);
            }
        }

        JSONArray attachments = m.optJSONArray("attachments");
        if (attachments != null) {
            for (int i = 0; i < attachments.length(); i++) {
                JSONObject a = attachments.optJSONObject(i); if (a == null) continue;
                String url = a.optString("url", ""); String filename = a.optString("filename", "attachment"); String ct = a.optString("content_type", "");
                if (ct.startsWith("image/") || filename.matches("(?i).*\\.(png|jpg|jpeg|gif|webp)$")) {
                    ImageView preview = new ImageView(this); preview.setScaleType(ImageView.ScaleType.CENTER_INSIDE); preview.setAdjustViewBounds(true); preview.setBackground(bg(PANEL_2, 13)); preview.setMinimumHeight(dp(70));
                    int maxW = (int)(getResources().getDisplayMetrics().widthPixels * 0.78f); LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(maxW, dp(230)); pp.setMargins(0, dp(8), 0, 0); body.addView(preview, pp); imageLoader.load(url, preview, null, io);
                    preview.setOnClickListener(v -> openUrl(url));
                } else {
                    TextView file = tv("📎  " + filename, 13, ACCENT); file.setPadding(dp(12), dp(10), dp(12), dp(10)); file.setBackground(bg(PANEL_2, 12)); LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.setMargins(0, dp(8), 0, 0); body.addView(file, fp); file.setOnClickListener(v -> openUrl(url));
                }
            }
        }

        // Polls / basic message components
        JSONObject poll = m.optJSONObject("poll");
        if (poll != null) {
            LinearLayout pollBox = column(); pollBox.setPadding(dp(11), dp(9), dp(11), dp(9)); pollBox.setBackground(bg(PANEL_2, 13));
            JSONObject q = poll.optJSONObject("question");
            pollBox.addView(bold(q == null ? "投票" : q.optString("text", "投票"), 14), lp(-1, -2));
            JSONArray answers = poll.optJSONArray("answers");
            if (answers != null) for (int i = 0; i < Math.min(12, answers.length()); i++) {
                JSONObject ans = answers.optJSONObject(i); if (ans == null) continue; JSONObject media = ans.optJSONObject("poll_media");
                TextView opt = tv("○ " + (media == null ? "選項" : media.optString("text", "選項")), 13, MUTED); opt.setPadding(dp(4), dp(5), 0, dp(2)); pollBox.addView(opt, lp(-1, -2));
            }
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.setMargins(0, dp(8), 0, 0); body.addView(pollBox, pp);
        }

        JSONArray components = m.optJSONArray("components");
        if (components != null && components.length() > 0) {
            LinearLayout componentBox = column(); componentBox.setPadding(0, dp(6), 0, 0);
            for (int i = 0; i < components.length(); i++) {
                JSONObject rowComp = components.optJSONObject(i); if (rowComp == null) continue;
                JSONArray children = rowComp.optJSONArray("components"); if (children == null) continue;
                LinearLayout componentRow = row();
                for (int j = 0; j < Math.min(5, children.length()); j++) {
                    JSONObject b = children.optJSONObject(j); if (b == null) continue;
                    int type = b.optInt("type", 0); String label = b.optString("label", "按鈕"); boolean disabled = b.optBoolean("disabled", false); String url = b.optString("url", "");
                    TextView button = tv(label.isEmpty() ? "按鈕" : label, 12, disabled ? SUBTLE : TEXT); button.setGravity(Gravity.CENTER); button.setSingleLine(true); button.setEllipsize(TextUtils.TruncateAt.END); button.setBackground(bg(disabled ? PANEL_2 : PANEL_3, 10));
                    LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(38), 1); bp.setMargins(0, 0, dp(6), 0); componentRow.addView(button, bp);
                    if (!disabled && !url.isEmpty()) button.setOnClickListener(v -> openUrl(url));
                    else if (!disabled && type == 2) button.setOnClickListener(v -> toast("此按鈕需要 Gateway Interaction 支援"));
                }
                componentBox.addView(componentRow, lp(-1, 42));
            }
            body.addView(componentBox, lp(-1, -2));
        }

        // Reactions
        JSONArray reactions = m.optJSONArray("reactions");
        if (reactions != null && reactions.length() > 0) {
            LinearLayout reactionsRow = row(); reactionsRow.setPadding(0, dp(8), 0, 0);
            for (int i = 0; i < reactions.length(); i++) {
                JSONObject rr = reactions.optJSONObject(i); if (rr == null) continue;
                JSONObject emoji = rr.optJSONObject("emoji"); String label = emoji == null ? "👍" : emoji.optString("name", "👍");
                int count = rr.optInt("count", 0); String id = emoji == null ? "" : emoji.optString("id", "");
                LinearLayout rb = row(); rb.setGravity(Gravity.CENTER); rb.setPadding(dp(7), 0, dp(9), 0); rb.setBackground(pressable(PANEL_2, PANEL_3, 9));
                if (!id.isEmpty()) { ImageView ri = new ImageView(this); ri.setScaleType(ImageView.ScaleType.CENTER_INSIDE); ri.setContentDescription(label); imageLoader.load(emojiCdnUrl(id, 32), ri, null, io); rb.addView(ri, lp(22, 22)); }
                else { TextView ru = tv(label, 17, TEXT); ru.setGravity(Gravity.CENTER); rb.addView(ru, lp(24, 24)); }
                TextView cnt = bold(String.valueOf(count), 11); cnt.setPadding(dp(4), 0, 0, 0); rb.addView(cnt, lp(-2, 26));
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, dp(32)); rp.setMargins(0, 0, dp(6), 0); reactionsRow.addView(rb, rp);
                final String emojiRef = id.isEmpty() ? label : (label + ":" + id);
                final boolean reacted = rr.optBoolean("me", false);
                if (reacted) rb.setBackground(pressable(Color.rgb(72,61,106), PANEL_3, 9));
                rb.setOnClickListener(v -> toggleReaction(m.optString("id", ""), emojiRef, reacted));
            }
            body.addView(reactionsRow, lp(-1, 38));
        }

        outer.addView(body, new LinearLayout.LayoutParams(0, -2, 1));
        outer.setOnLongClickListener(v -> { showMessageActions(m); return true; });
        return outer;
    }

    private final class ChatAdapter extends BaseAdapter {
        @Override public int getCount() { return messageItems.size(); }
        @Override public JSONObject getItem(int position) { return messageItems.get(position); }
        @Override public long getItemId(int position) { try { return Long.parseUnsignedLong(messageItems.get(position).optString("id", "0")); } catch (Throwable ignored) { return position; } }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout recycled = convertView instanceof LinearLayout ? (LinearLayout) convertView : null;
            return buildMessageRowInto(recycled, messageItems.get(position));
        }
    }

    private static final class RichPart {
        static final int TEXT = 0, MENTION = 1, EMOJI = 2, EVERYONE = 3;
        final int type; final String text; final String url;
        RichPart(int type, String text, String url) { this.type = type; this.text = text; this.url = url; }
    }

    private List<RichPart> parseDiscordContent(String content, JSONObject message) {
        List<RichPart> parts = new ArrayList<>();
        Map<String, String> userNames = new HashMap<>();
        JSONArray mentions = message.optJSONArray("mentions");
        if (mentions != null) for (int i = 0; i < mentions.length(); i++) { JSONObject u = mentions.optJSONObject(i); if (u == null) continue; String id = u.optString("id", ""); if (!id.isEmpty()) userNames.put(id, safeDisplayName(u)); }
        Matcher matcher = DISCORD_RICH_TOKEN.matcher(content == null ? "" : content); int last = 0;
        while (matcher.find()) {
            if (matcher.start() > last) parts.add(new RichPart(RichPart.TEXT, content.substring(last, matcher.start()), null));
            String anim = matcher.group(1); String emojiName = matcher.group(2); String emojiId = matcher.group(3);
            String userId = matcher.group(4); String roleId = matcher.group(5); String channelId = matcher.group(6); String special = matcher.group(7);
            if (emojiId != null) {
                parts.add(new RichPart(RichPart.EMOJI, ":" + emojiName + ":", emojiCdnUrl(emojiId, 64)));
            } else if (userId != null) {
                parts.add(new RichPart(RichPart.MENTION, "@" + userNames.getOrDefault(userId, "使用者"), "user:" + userId));
            } else if (roleId != null) {
                parts.add(new RichPart(RichPart.MENTION, "@" + roleNameById.getOrDefault(roleId, "角色"), "role:" + roleId));
            } else if (channelId != null) {
                JSONObject c = channelById.get(channelId); parts.add(new RichPart(RichPart.MENTION, "#" + (c == null ? "頻道" : normalizeChannelName(c.optString("name", "頻道"))), "channel:" + channelId));
            } else if (special != null) {
                parts.add(new RichPart(RichPart.EVERYONE, "@" + special, null));
            }
            last = matcher.end();
        }
        if (last < content.length()) parts.add(new RichPart(RichPart.TEXT, content.substring(last), null));
        return parts;
    }

    private String safeDisplayName(JSONObject u) {
        if (u == null) return "使用者";
        String n = jsonText(u, "global_name", "");
        if (n.isEmpty()) n = jsonText(u, "username", "");
        if (n.isEmpty()) n = jsonText(u, "display_name", "");
        return n.isEmpty() ? "使用者" : n;
    }

    private String jsonText(JSONObject o, String key, String fallback) {
        if (o == null || !o.has(key) || o.isNull(key)) return fallback;
        String value = o.optString(key, fallback);
        if (value == null) return fallback;
        value = value.trim();
        return value.isEmpty() || "null".equalsIgnoreCase(value) ? fallback : value;
    }

    private Bitmap scaleForInlineEmoji(Bitmap b, int targetH) {
        if (b == null || b.getHeight() <= 0) return b;
        float scale = Math.min(1.0f, targetH / (float) b.getHeight());
        return Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth()*scale)), Math.max(1, Math.round(b.getHeight()*scale)), true);
    }

    private SpannableStringBuilder buildRichText(List<RichPart> parts, Map<String, Bitmap> emojiBitmaps) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        for (RichPart p : parts) {
            int start = out.length(); out.append(p.text); int end = out.length();
            if (p.type == RichPart.MENTION) {
                int color = ACCENT;
                if (p.url != null && p.url.startsWith("role:")) { int c = roleColorById.getOrDefault(p.url.substring(5), 0); if (c != 0) color = Color.rgb((c>>16)&255, (c>>8)&255, c&255); }
                out.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new BackgroundColorSpan(Color.argb(55, Color.red(color), Color.green(color), Color.blue(color))), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (p.type == RichPart.EVERYONE) {
                out.setSpan(new ForegroundColorSpan(Color.rgb(255,119,144)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new BackgroundColorSpan(Color.argb(55,255,119,144)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (p.type == RichPart.EMOJI) {
                Bitmap b = emojiBitmaps == null ? null : emojiBitmaps.get(p.url);
                if (b != null) out.setSpan(new ImageSpan(this, scaleForInlineEmoji(b, dp(22)), ImageSpan.ALIGN_BOTTOM), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                else out.setSpan(new ForegroundColorSpan(MUTED), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        return out;
    }

    private void renderDiscordContent(TextView view, String content, JSONObject message) {
        String cacheKey = message.optString("id", "") + "|" + (content == null ? "" : content);
        List<RichPart> parts = richPartsCache.get(cacheKey);
        if (parts == null) {
            parts = parseDiscordContent(content == null ? "" : content, message);
            if (richPartsCache.size() > 500) richPartsCache.clear();
            richPartsCache.put(cacheKey, parts);
        }
        // Render text immediately. Never block a message row on disk/network image decoding.
        view.setText(buildRichText(parts, Collections.emptyMap()));

        final String tag = "msg-rich-" + message.optString("id", "");
        final List<RichPart> renderParts = parts;
        view.setTag(tag);
        Set<String> missing = new HashSet<>();
        for (RichPart p : parts) {
            if (p.type == RichPart.EMOJI && p.url != null && missing.add(p.url)) {
                if (imageLoader.getCached(p.url) == null) imageLoader.preload(p.url, io);
            }
        }
        if (missing.isEmpty()) {
            renderRichCached(view, parts, tag);
            return;
        }
        // Two cheap UI refreshes instead of synchronous loadSync(): most CDN hits appear on the first.
        view.postDelayed(() -> renderRichCached(view, renderParts, tag), 180);
        view.postDelayed(() -> renderRichCached(view, renderParts, tag), 700);
    }

    private void renderRichCached(TextView view, List<RichPart> parts, String tag) {
        if (!tag.equals(view.getTag())) return;
        Map<String, Bitmap> maps = new HashMap<>();
        boolean complete = true;
        for (RichPart p : parts) {
            if (p.type != RichPart.EMOJI || maps.containsKey(p.url)) continue;
            Bitmap b = imageLoader.getCached(p.url);
            if (b != null) maps.put(p.url, b);
            else complete = false;
        }
        if (!maps.isEmpty()) view.setText(buildRichText(parts, maps));
        // If the first pass missed the CDN, leave the readable :emoji: fallback instead of blocking.
    }

    private String emojiCdnUrl(String emojiId, int size) {
        return "https://cdn.discordapp.com/emojis/" + emojiId + ".png?size=" + size + "&quality=lossless";
    }

    private void warmMessageAvatars(List<JSONObject> items) {
        Set<String> seen = new HashSet<>();
        int warmed = 0;
        for (JSONObject m : items) {
            if (warmed >= 8) break;
            JSONObject a = m.optJSONObject("author");
            if (a == null) continue;
            String url = avatarUrl(a.optString("id", ""), a.optString("avatar", ""));
            if (url.isEmpty() || !seen.add(url)) continue;
            imageLoader.preload(url, io);
            warmed++;
        }
    }

    private void warmGuildEmojiImages(JSONArray emojis) {
        if (emojis == null) return;
        int count = 0;
        for (int i = 0; i < emojis.length() && count < 80; i++) {
            JSONObject e = emojis.optJSONObject(i);
            if (e == null) continue;
            String id = e.optString("id", "");
            if (id.isEmpty()) continue;
            imageLoader.preload(emojiCdnUrl(id, 64), io);
            count++;
        }
    }

    private void showUserCard(JSONObject author) {
        if (author == null) return; String name = safeDisplayName(author); String username = author.optString("username", name); String id = author.optString("id", "");
        LinearLayout box = column(); box.setPadding(dp(14), dp(8), dp(14), dp(10)); box.addView(bold(name,18), lp(-1,34)); box.addView(tv("@"+username,12,MUTED),lp(-1,24)); box.addView(tv("ID："+(id.isEmpty()?"未知":id),12,SUBTLE),lp(-1,24));
        TextView copy = tv("複製使用者 ID",13,ACCENT); copy.setGravity(Gravity.CENTER); copy.setBackground(pressable(PANEL_2,PANEL_3,12)); box.addView(copy,lp(-1,42)); copy.setOnClickListener(v->copyText(id)); showDialog(box,"使用者資料");
    }

    private void sendCurrentMessage(Uri attachment) {
        if (chatBusy || currentChannelId == null) return;
        final String content = composer == null ? "" : composer.getText().toString().trim();
        if (content.isEmpty() && attachment == null) return;
        final String editId = editingMessageId;
        final String replyId = replyToMessageId;
        chatBusy = true; setChatEnabled(false); status(editId != null ? "更新訊息…" : "送出中…", MUTED);
        io.execute(() -> {
            try {
                if (editId != null) api.editMessage(currentChannelId, editId, content);
                else if (attachment != null) api.sendFile(currentChannelId, content, attachment, displayName(attachment), replyId);
                else if (replyId != null) api.replyMessage(currentChannelId, content, replyId);
                else api.sendMessage(currentChannelId, content);
                runOnUiThread(() -> {
                    if (composer != null) composer.setText("");
                    editingMessageId = null; editingOriginalContent = null; replyToMessageId = null;
                    chatBusy = false; setChatEnabled(true); status(editId != null ? "已更新" : "● 連線正常 · REST Polling", GREEN); loadMessages(true, null);
                });
            } catch (Throwable t) {
                runOnUiThread(() -> { chatBusy = false; setChatEnabled(true); status("操作失敗", RED); toast(friendlyError(t)); });
            }
        });
    }

    private void setChatEnabled(boolean enabled) {
        if (composer != null) composer.setEnabled(enabled);
        if (sendButton != null) sendButton.setEnabled(enabled);
        if (attachButton != null) attachButton.setEnabled(enabled);
        if (emojiButton != null) emojiButton.setEnabled(enabled);
    }

    private void loadMessages(boolean replace, String before) {
        if (currentChannelId == null || refreshInFlight.getAndSet(true)) return;
        status(replace ? "載入訊息…" : "載入更早訊息…", MUTED);
        io.execute(() -> {
            try {
                JSONArray arr = api.messages(currentChannelId, before, replace ? 75 : 50);
                runOnUiThread(() -> { refreshInFlight.set(false); renderMessages(arr, replace); status("● 連線正常 · 3 秒同步", GREEN); });
            } catch (Throwable t) {
                runOnUiThread(() -> { refreshInFlight.set(false); loadingOlder = false; status("載入失敗", RED); toast(friendlyError(t)); });
            }
        });
    }

    private void pollNewMessages() {
        if (currentChannelId == null || refreshInFlight.getAndSet(true)) return;
        io.execute(() -> {
            try {
                if (latestMessageId == null) {
                    JSONArray arr = api.messages(currentChannelId, null, 75);
                    runOnUiThread(() -> { refreshInFlight.set(false); renderMessages(arr, true); });
                    return;
                }
                JSONArray arr = api.messagesAfter(currentChannelId, latestMessageId, 25);
                runOnUiThread(() -> { refreshInFlight.set(false); appendNewMessages(arr); status("● 連線正常 · 3 秒同步", GREEN); });
            } catch (Throwable t) {
                runOnUiThread(() -> refreshInFlight.set(false));
            }
        });
    }

    private void appendNewMessages(JSONArray list) {
        if (list == null || list.length() == 0) return;
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < list.length(); i++) { JSONObject m = list.optJSONObject(i); if (m != null) items.add(m); }
        Collections.reverse(items);
        if (items.isEmpty()) return;
        Set<String> existing = new HashSet<>();
        for (JSONObject m : messageItems) existing.add(m.optString("id", ""));
        List<JSONObject> fresh = new ArrayList<>();
        for (JSONObject m : items) if (!existing.contains(m.optString("id", ""))) fresh.add(m);
        if (fresh.isEmpty()) return;
        boolean atBottom = messageList != null && messageList.getLastVisiblePosition() >= messageItems.size() - 2;
        messageItems.addAll(fresh);
        latestMessageId = messageItems.get(messageItems.size() - 1).optString("id", latestMessageId);
        lastMessageFingerprint = "";
        warmMessageAvatars(fresh);
        if (chatAdapter != null) chatAdapter.notifyDataSetChanged();
        if (atBottom && messageList != null) messageList.post(() -> messageList.setSelection(messageItems.size() - 1));
        else status("有 " + fresh.size() + " 則新訊息 · 回到底部查看", ACCENT);
    }

    private void startPolling() {
        stopPolling();
        pollFuture = scheduler.scheduleWithFixedDelay(() -> {
            if (currentChannelId == null || isFinishing()) return;
            pollNewMessages();
            long now = System.currentTimeMillis();
            if (now - lastFullSyncAt > 30000L) {
                lastFullSyncAt = now;
                loadMessages(true, null);
            }
        }, 3, 3, TimeUnit.SECONDS);
    }

    private void stopPolling() {
        if (pollFuture != null) {
            pollFuture.cancel(false);
            pollFuture = null;
        }
    }

    private void status(String s, int color) {
        if (statusText != null) runOnUiThread(() -> { statusText.setText(s); statusText.setTextColor(color); });
    }

    // ---------------------------------------------------------------------
    // API loading
    // ---------------------------------------------------------------------
    private void loadGuilds() {
        io.execute(() -> {
            try {
                JSONArray result = api.guilds(); guilds = result;
                for (int i = 0; i < result.length() && i < 40; i++) {
                    JSONObject g = result.optJSONObject(i);
                    if (g == null) continue;
                    String gid = g.optString("id", ""); String hash = g.optString("icon", "");
                    if (!gid.isEmpty() && !hash.isEmpty()) imageLoader.preload("https://cdn.discordapp.com/icons/" + gid + "/" + hash + ".png?size=96", io);
                }
                runOnUiThread(() -> { buildNavigation(); if (guilds.length() > 0) selectGuild(guilds.optJSONObject(0)); });
            } catch (Throwable t) { runOnUiThread(() -> toast("載入伺服器失敗：" + friendlyError(t))); }
        });
    }

    private void loadChannels(String guildId, boolean keepCurrent) {
        io.execute(() -> {
            try {
                JSONArray result = api.channels(guildId); channels = result;
                runOnUiThread(() -> { if (!keepCurrent) currentChannelId = null; buildChannelPane(); });
            } catch (Throwable t) { runOnUiThread(() -> toast("載入頻道失敗：" + friendlyError(t))); }
        });
    }

    private void loadGuildExtras(String guildId) {
        if (guildId == null || guildId.isEmpty()) return;
        io.execute(() -> {
            try {
                JSONArray e = api.guildEmojis(guildId);
                JSONArray s = api.guildStickers(guildId);
                JSONArray r = api.roles(guildId);
                runOnUiThread(() -> {
                    guildEmojis = e; guildStickers = s; emojiById.clear();
                    for (int i = 0; i < guildEmojis.length(); i++) { JSONObject x = guildEmojis.optJSONObject(i); if (x != null) emojiById.put(x.optString("id", ""), x); }
                    roleNameById.clear(); roleColorById.clear();
                    for (int i = 0; i < r.length(); i++) { JSONObject role = r.optJSONObject(i); if (role == null) continue; String rid = role.optString("id", ""); if (!rid.isEmpty()) { roleNameById.put(rid, jsonText(role, "name", "角色")); roleColorById.put(rid, role.optInt("color", 0)); } }
                    richPartsCache.clear();
                    warmGuildEmojiImages(guildEmojis);
                    if (chatAdapter != null && !messageItems.isEmpty() && currentGuildId != null && currentGuildId.equals(guildId)) {
                        lastMessageFingerprint = "";
                        chatAdapter.notifyDataSetChanged();
                    }
                });
            } catch (Throwable ignored) { }
        });
    }

    // ---------------------------------------------------------------------
    // Message actions / composer extras
    // ---------------------------------------------------------------------
    private void showComposerMenu() {
        LinearLayout box = column(); box.setPadding(dp(12), dp(6), dp(12), dp(10));
        addAction(box, "📎  圖片 / 檔案", this::pickFile);
        addAction(box, "😀  Emoji / 自製表情", this::showEmojiPicker);
        addAction(box, "🎟  貼圖", this::showStickerPicker);
        addAction(box, "📊  建立投票", this::showPollDialog);
        addAction(box, "🔗  頻道資訊", this::showChannelInfo);
        showDialog(box, "更多功能");
    }

    private void addAction(LinearLayout box, String text, Runnable action) {
        TextView b = tv(text, 14, TEXT); b.setGravity(Gravity.CENTER_VERTICAL); b.setPadding(dp(14), 0, dp(12), 0); b.setBackground(pressable(PANEL_2, PANEL_3, 14)); box.addView(b, lp(-1, 48)); b.setOnClickListener(v -> action.run());
    }

    private void showMessageActions(JSONObject m) {
        LinearLayout box = column(); box.setPadding(dp(12), dp(6), dp(12), dp(10));
        addAction(box, "↩ 回覆", () -> beginReply(m));
        addAction(box, "😀 加入反應", () -> showEmojiPickerForMessage(m));
        addAction(box, "📌 釘選", () -> togglePin(m));
        addAction(box, "📍 解除釘選", () -> unpinMessage(m));
        addAction(box, "📍 查看釘選訊息", this::showPinnedMessages);
        addAction(box, "📋 複製文字", () -> copyText(m.optString("content", "")));
        addAction(box, "🔗 複製訊息連結", () -> copyText("https://discord.com/channels/" + currentGuildId + "/" + currentChannelId + "/" + m.optString("id", "")));
        addAction(box, "🆔 複製訊息 ID", () -> copyText(m.optString("id", "")));

        String authorId = m.optJSONObject("author") == null ? "" : m.optJSONObject("author").optString("id", "");
        if (me != null && authorId.equals(me.optString("id", ""))) {
            addAction(box, "✏️ 編輯", () -> beginEdit(m));
            addAction(box, "🗑️ 收回訊息", () -> confirmDelete(m));
        }
        addAction(box, "👤 查看作者", () -> showUserCard(m.optJSONObject("author")));
        int currentType = 0;
        try { currentType = channelById.getOrDefault(currentChannelId, new JSONObject()).optInt("type", 0); } catch (Throwable ignored) {}
        if (currentType == 5) addAction(box, "📣 發佈到追蹤頻道", () -> crosspostMessage(m));
        addAction(box, "🧵 建立討論串", () -> createThread(m));
        showDialog(box, "訊息操作");
    }

    private void beginReply(JSONObject m) { JSONObject a=m.optJSONObject("author"); String uname=a==null?"訊息":a.optString("username","訊息"); replyToMessageId = m.optString("id", null); editingMessageId = null; if (composer != null) { composer.setHint("↩ 回覆 " + uname + "…"); composer.requestFocus(); } toast("已準備回覆"); }

    private void beginEdit(JSONObject m) { editingMessageId = m.optString("id", null); editingOriginalContent = m.optString("content", ""); replyToMessageId = null; if (composer != null) { composer.setText(editingOriginalContent); composer.setSelection(composer.length()); composer.setHint("編輯訊息…"); composer.requestFocus(); } toast("現在是編輯模式，再按送出即可更新"); }

    private void copyText(String text) { ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("message", text)); toast("已複製"); }

    private void confirmDelete(JSONObject m) {
        new AlertDialog.Builder(this).setTitle("收回訊息").setMessage("確定要收回這則訊息嗎？").setNegativeButton("取消", null).setPositiveButton("收回", (d, w) -> io.execute(() -> { try { api.deleteMessage(currentChannelId, m.optString("id", "")); runOnUiThread(() -> { toast("訊息已收回"); loadMessages(true, null); }); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } })).show();
    }

    private void togglePin(JSONObject m) {
        io.execute(() -> { try { api.pinMessage(currentChannelId, m.optString("id", "")); runOnUiThread(() -> toast("已釘選訊息")); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } });
    }

    private void unpinMessage(JSONObject m) {
        io.execute(() -> { try { api.unpinMessage(currentChannelId, m.optString("id", "")); runOnUiThread(() -> toast("已解除釘選")); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } });
    }

    private void crosspostMessage(JSONObject m) {
        io.execute(() -> { try { api.crosspostMessage(currentChannelId, m.optString("id", "")); runOnUiThread(() -> toast("已發佈")); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } });
    }

    private void showPinnedMessages() {
        io.execute(() -> { try { JSONArray pins = api.pinnedMessages(currentChannelId); runOnUiThread(() -> { LinearLayout box = column(); box.setPadding(dp(10), dp(6), dp(10), dp(8)); for (int i = 0; i < Math.min(40, pins.length()); i++) { JSONObject itemObj = pins.optJSONObject(i); if (itemObj == null) continue; JSONObject m = itemObj.optJSONObject("message"); if (m == null) m = itemObj; JSONObject a = m.optJSONObject("author"); String text = safeDisplayName(a) + " · " + formatTime(m.optString("timestamp", "")) + "\n" + m.optString("content", "(附件/無文字)"); TextView item = tv(text, 12, TEXT); item.setPadding(dp(10), dp(8), dp(10), dp(8)); item.setBackground(pressable(PANEL_2, PANEL_3, 12)); box.addView(item, lp(-1, -2)); } if (pins.length() == 0) box.addView(tv("目前沒有釘選訊息", 13, MUTED), lp(-1, 50)); showDialog(box, "釘選訊息"); }); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } });
    }

    private void toggleReaction(String messageId, String emojiRef, boolean reacted) { io.execute(() -> { try { if (reacted) api.removeReaction(currentChannelId, messageId, emojiRef); else api.addReaction(currentChannelId, messageId, emojiRef); runOnUiThread(() -> pollNewMessages()); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } }); }

    private void showEmojiPickerForMessage(JSONObject m) {
        showEmojiPickerInternal(emoji -> toggleReaction(m.optString("id", ""), emoji, false), true);
    }

    private void showEmojiPicker() { showEmojiPickerInternal(emoji -> { if (composer != null) { composer.append(emoji); composer.requestFocus(); } }, false); }

    private interface EmojiCallback { void use(String emoji); }

    private void showEmojiPickerInternal(EmojiCallback callback, boolean forReaction) {
        LinearLayout box = column(); box.setPadding(dp(12), dp(6), dp(12), dp(10));
        LinearLayout quick = row();
        String[] quickEmoji = {"😀","😂","🥹","😍","😭","😡","👍","👎","❤️","🔥","🎉","🤔"};
        for (String e : quickEmoji) { TextView b = tv(e, 24, TEXT); b.setGravity(Gravity.CENTER); b.setBackground(pressable(Color.TRANSPARENT, PANEL_3, 12)); quick.addView(b, lp(44, 44)); b.setOnClickListener(v -> { callback.use(e); }); }
        box.addView(quick, lp(-1, 46));

        if (guildEmojis.length() > 0) {
            TextView sub = tv("伺服器自製 Emoji", 12, MUTED); sub.setPadding(dp(4), dp(10), 0, dp(6)); box.addView(sub, lp(-1, 30));
            ScrollView sc = new ScrollView(this); LinearLayout grid = column();
            LinearLayout current = null; int count = 0;
            for (int i = 0; i < guildEmojis.length(); i++) {
                JSONObject e = guildEmojis.optJSONObject(i); if (e == null) continue;
                if (count % 5 == 0) { current = row(); grid.addView(current, lp(-1, 52)); }
                String eid = e.optString("id", ""); String ename = e.optString("name", "emoji"); String animated = e.optBoolean("animated", false) ? "a" : "";
                String url = emojiCdnUrl(eid, 64);
                FrameLayoutWrap eb = new FrameLayoutWrap(this); eb.setBackground(pressable(PANEL_2, PANEL_3, 10));
                ImageView ei = new ImageView(this); ei.setScaleType(ImageView.ScaleType.CENTER_INSIDE); eb.add(ei, lp(58, 44));
                TextView et = tv(ename, 8, MUTED); et.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); eb.add(et, new android.widget.FrameLayout.LayoutParams(dp(58), dp(16), Gravity.BOTTOM));
                if (!url.isEmpty()) imageLoader.load(url, ei, null, io);
                current.addView(eb, lp(58, 44));
                final String code = forReaction ? (ename + ":" + eid) : ("<" + animated + ":" + ename + ":" + eid + ">");
                eb.setOnClickListener(v -> callback.use(code)); count++;
            }
            sc.addView(grid); box.addView(sc, new LinearLayout.LayoutParams(-1, dp(170)));
        }
        TextView manage = tv("＋ 自製 Emoji（從圖片建立）", 13, ACCENT); manage.setGravity(Gravity.CENTER); manage.setBackground(pressable(PANEL_2, PANEL_3, 14)); box.addView(manage, lp(-1, 46)); manage.setOnClickListener(v -> pickEmojiImage());
        showDialog(box, "Emoji");
    }

    private void showStickerPicker() {
        LinearLayout box = column(); box.setPadding(dp(12), dp(6), dp(12), dp(10));
        if (guildStickers.length() == 0) box.addView(tv("此伺服器沒有可用貼圖。", 13, MUTED), lp(-1, 50));
        for (int i = 0; i < Math.min(50, guildStickers.length()); i++) {
            JSONObject s = guildStickers.optJSONObject(i); if (s == null) continue;
            String name = s.optString("name", "Sticker"); String id = s.optString("id", "");
            TextView item = tv("🎟 " + name, 13, TEXT); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(12),0,0,0); item.setBackground(pressable(PANEL_2, PANEL_3, 12)); box.addView(item, lp(-1, 44)); item.setOnClickListener(v -> io.execute(() -> { try { api.sendSticker(currentChannelId, id); runOnUiThread(() -> { toast("已送出貼圖"); loadMessages(true, null); }); } catch (Throwable t) { runOnUiThread(() -> toast(friendlyError(t))); } }));
        }
        showDialog(box, "貼圖");
    }

    private void showPollDialog() {
        LinearLayout box = column(); box.setPadding(dp(14), dp(8), dp(14), dp(8));
        EditText q = new EditText(this); q.setHint("投票問題"); q.setTextColor(TEXT); q.setHintTextColor(SUBTLE); q.setBackground(bg(PANEL_2, 13)); q.setPadding(dp(12),0,dp(12),0); box.addView(q, lp(-1, 48));
        EditText a = new EditText(this); a.setHint("選項，用逗號分隔，例如：A,B,C"); a.setTextColor(TEXT); a.setHintTextColor(SUBTLE); a.setBackground(bg(PANEL_2, 13)); a.setPadding(dp(12),0,dp(12),0); LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1,48); ap.setMargins(0,dp(8),0,0); box.addView(a,ap);
        TextView send = tv("建立投票", 14, TEXT); send.setGravity(Gravity.CENTER); send.setBackground(pressable(ACCENT, Color.rgb(115,99,203),14)); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,48); sp.setMargins(0,dp(10),0,0); box.addView(send,sp);
        android.app.Dialog[] holder = new android.app.Dialog[1]; send.setOnClickListener(v -> { String question=q.getText().toString().trim(); String options=a.getText().toString().trim(); if(question.isEmpty()||options.isEmpty()){toast("請輸入問題和選項");return;} if(holder[0]!=null)holder[0].dismiss(); String[] parts=options.split(","); io.execute(() -> { try { api.createPoll(currentChannelId, question, parts); runOnUiThread(() -> {toast("投票已建立");loadMessages(true,null);}); }catch(Throwable t){runOnUiThread(()->toast(friendlyError(t)));}}); });
        final android.app.Dialog d = new android.app.Dialog(this); holder[0]=d; LinearLayout wrap=column(); wrap.setPadding(dp(18),dp(14),dp(18),dp(18)); wrap.setBackground(bg(PANEL,22)); wrap.addView(bold("建立投票",18),lp(-1,42)); wrap.addView(box,lp(-1,-2)); TextView close=tv("關閉",13,ACCENT); close.setGravity(Gravity.CENTER); wrap.addView(close,lp(-1,44)); close.setOnClickListener(v->d.dismiss()); d.setContentView(wrap); d.show(); if(d.getWindow()!=null){d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92f),-2);}
    }

    private void showMessageSearch() {
        final EditText input = new EditText(this); input.setSingleLine(true); input.setHint("搜尋目前頻道的訊息"); input.setTextColor(TEXT); input.setHintTextColor(SUBTLE); input.setPadding(dp(12),0,dp(12),0); input.setBackground(bg(PANEL_2,14));
        new AlertDialog.Builder(this).setTitle("搜尋訊息").setView(input).setNegativeButton("取消",null).setPositiveButton("搜尋",(d,w)->runMessageSearch(input.getText().toString().trim())).show();
    }

    private void runMessageSearch(String text) { if(text.isEmpty()||currentGuildId==null)return; io.execute(() -> {try{JSONArray hits=api.searchMessages(currentGuildId,currentChannelId,text); runOnUiThread(()->showSearchResults(hits));}catch(Throwable t){runOnUiThread(()->toast(friendlyError(t)));}}); }

    private void showSearchResults(JSONArray hits) { LinearLayout box=column(); box.setPadding(dp(10),dp(6),dp(10),dp(8)); if(hits.length()==0)box.addView(tv("沒有結果",13,MUTED),lp(-1,44)); for(int i=0;i<Math.min(25,hits.length());i++){JSONObject m=hits.optJSONObject(i);if(m==null)continue;String c=m.optString("content","(附件或無文字)");TextView t=tv("#"+currentChannelName+"\n"+c,12,TEXT);t.setPadding(dp(10),dp(8),dp(10),dp(8));t.setBackground(pressable(PANEL_2,PANEL_3,12));box.addView(t,lp(-1,-2));}showDialog(box,"搜尋結果"); }

    private void showInputDialog(String title, String hint, String value, java.util.function.Consumer<String> callback) {
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint(hint);input.setText(value==null?"":value);input.setTextColor(TEXT);input.setHintTextColor(SUBTLE);input.setPadding(dp(12),0,dp(12),0);input.setBackground(bg(PANEL_2,14));new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("取消",null).setPositiveButton("確定",(d,w)->callback.accept(input.getText().toString().trim())).show();
    }

    private void createThread(JSONObject m) {
        showInputDialog("建立討論串","討論串名稱","",name -> { if(name.isEmpty())return; io.execute(()->{try{api.createThread(currentChannelId,m.optString("id",""),name);runOnUiThread(()->{toast("討論串已建立");});}catch(Throwable t){runOnUiThread(()->toast(friendlyError(t)));}}); });
    }

    private void pickEmojiImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_EMOJI_IMAGE);}

    // ---------------------------------------------------------------------
    // File, settings, helpers
    // ---------------------------------------------------------------------
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode == PICK_FILE) sendCurrentMessage(data.getData());
        else if (requestCode == PICK_EMOJI_IMAGE) createEmojiFromUri(data.getData());
    }

    private void createEmojiFromUri(Uri uri) {
        if (currentGuildId == null) { toast("請先選擇伺服器"); return; }
        showInputDialog("建立自製 Emoji", "名稱（最多 32 字）", "mini", name -> {
            if (name.isEmpty()) return;
            io.execute(() -> {
                try {
                    byte[] bytes = readAndDownscaleImage(uri);
                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    api.createGuildEmoji(currentGuildId, name, "data:image/png;base64," + b64);
                    runOnUiThread(() -> { toast("Emoji 已建立"); loadGuildExtras(currentGuildId); });
                } catch (Throwable t) { runOnUiThread(() -> toast("建立 Emoji 失敗：" + friendlyError(t))); }
            });
        });
    }

    private byte[] readAndDownscaleImage(Uri uri) throws Exception {
        android.graphics.Bitmap src = android.graphics.BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
        if (src == null) throw new IllegalArgumentException("圖片無法讀取");
        int max = 128; float scale = Math.min(1f, Math.min(max/(float)src.getWidth(), max/(float)src.getHeight()));
        int w=Math.max(1,Math.round(src.getWidth()*scale)), h=Math.max(1,Math.round(src.getHeight()*scale));
        android.graphics.Bitmap out=android.graphics.Bitmap.createScaledBitmap(src,w,h,true);
        ByteArrayOutputStream bos=new ByteArrayOutputStream(); out.compress(android.graphics.Bitmap.CompressFormat.PNG,100,bos);
        out.recycle(); src.recycle();
        byte[] bytes=bos.toByteArray();
        if(bytes.length<=256*1024)return bytes;
        android.graphics.Bitmap src2 = android.graphics.BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
        if (src2 == null) throw new IllegalArgumentException("圖片無法讀取");
        android.graphics.Bitmap tiny=android.graphics.Bitmap.createScaledBitmap(src2,64,64,true);
        src2.recycle(); bos.reset(); tiny.compress(android.graphics.Bitmap.CompressFormat.PNG,100,bos); tiny.recycle();
        bytes=bos.toByteArray();
        if(bytes.length>256*1024) throw new IllegalArgumentException("圖片太大，請選擇較簡單的圖片");
        return bytes;
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (idx >= 0) return c.getString(idx); }
        } catch (Exception ignored) { }
        return "attachment";
    }

    private void showSettings() {
        LinearLayout box = column(); box.setPadding(dp(18), dp(16), dp(18), dp(18)); box.setBackground(bg(PANEL, 24));
        TextView title = bold("Mini Client 設定", 20); box.addView(title, lp(-1, 44));
        TextView about = tv("版本 4.0 Mobile Optimized\nDiscord-style UI · REST-first · Message Tools · Emoji / Sticker", 12, MUTED); about.setPadding(0, 0, 0, dp(16)); box.addView(about, lp(-1, -2));
        TextView saved = tv("🔐 Token 儲存：Android Keystore", 13, GREEN); saved.setPadding(dp(12), dp(12), dp(12), dp(12)); saved.setBackground(bg(PANEL_2, 14)); box.addView(saved, lp(-1, 48));
        TextView poll = tv("⚡ 即時更新：目前使用 REST Polling（3 秒）\n訊息工具：編輯、收回、回覆、反應、釘選、討論串、搜尋、投票、Emoji、貼圖、附件。", 13, TEXT); poll.setPadding(dp(12), dp(12), dp(12), dp(12)); poll.setBackground(bg(PANEL_2, 14)); LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.setMargins(0, dp(10), 0, 0); box.addView(poll, pp);
        TextView crash = tv("查看上次崩潰記錄", 13, ACCENT); crash.setGravity(Gravity.CENTER); crash.setBackground(pressable(PANEL_2, PANEL_3, 14)); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 48); cp.setMargins(0, dp(10), 0, 0); box.addView(crash, cp);
        crash.setOnClickListener(v -> showCrashLog());
        TextView logout = tv("登出並清除本機 Token", 14, RED); logout.setGravity(Gravity.CENTER); logout.setBackground(pressable(Color.rgb(57, 25, 33), Color.rgb(76, 33, 42), 14)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 50); lp.setMargins(0, dp(10), 0, 0); box.addView(logout, lp);
        logout.setOnClickListener(v -> { secureStore.clear(); token = null; api = null; me = null; toast("已登出"); showLogin(); });
        showDialog(box, "設定");
    }

    private void showCrashLog() {
        String log = getSharedPreferences("diagnostics", MODE_PRIVATE).getString("last_crash", "目前沒有保存的崩潰記錄。");
        TextView body = tv(log, 11, MUTED); body.setPadding(dp(12), dp(12), dp(12), dp(12)); body.setBackground(bg(PANEL_2, 14)); ScrollView s = new ScrollView(this); s.addView(body); showDialog(s, "上次崩潰記錄");
    }

    private void showChannelInfo() {
        TextView t = tv("# " + currentChannelName + "\n\nGuild：" + currentGuildName + "\nChannel ID：" + currentChannelId + "\n\n可用功能：搜尋、回覆、編輯、收回、反應、釘選、討論串、Emoji、貼圖、投票、附件。\n\n訊息透過 Discord HTTP API 讀取。", 13, MUTED); t.setPadding(dp(14), dp(12), dp(14), dp(12)); t.setBackground(bg(PANEL_2, 16)); showDialog(t, "頻道資訊");
    }

    private void showDialog(View body, String titleText) {
        final android.app.Dialog d = new android.app.Dialog(this); d.getWindow(); LinearLayout wrap = column(); wrap.setPadding(dp(18), dp(14), dp(18), dp(18)); wrap.setBackground(bg(PANEL, 22)); TextView title = bold(titleText, 18); wrap.addView(title, lp(-1, 42)); wrap.addView(body, lp(-1, -2)); TextView close = tv("關閉", 13, ACCENT); close.setGravity(Gravity.CENTER); close.setBackground(pressable(PANEL_2, PANEL_3, 14)); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 46); cp.setMargins(0, dp(12), 0, 0); wrap.addView(close, cp); close.setOnClickListener(v -> d.dismiss()); d.setContentView(wrap); Window w = d.getWindow(); if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(-1, -2); } d.show(); if (d.getWindow() != null) { d.getWindow().setBackgroundDrawableResource(android.R.color.transparent); d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * .92f), -2); } }

    private void loadMeAvatar() {
        if (userAvatar == null || me == null) return;
        String url = avatarUrl(me.optString("id", "0"), me.optString("avatar", "")); if (!url.isEmpty()) imageLoader.load(url, userAvatar, null, io);
    }

    private String avatarUrl(String id, String hash) {
        if (id == null || id.isEmpty()) return "";
        if (hash == null || hash.isEmpty()) {
            try { long n = Long.parseUnsignedLong(id); return "https://cdn.discordapp.com/embed/avatars/" + (n % 6) + ".png?size=96"; } catch (Exception ignored) { return "https://cdn.discordapp.com/embed/avatars/0.png?size=96"; }
        }
        return "https://cdn.discordapp.com/avatars/" + id + "/" + hash + ".png?size=96";
    }

    private String firstLetter(String s) { String x = s == null ? "M" : s.trim(); return x.isEmpty() ? "M" : x.substring(0, 1).toUpperCase(Locale.ROOT); }
    private String formatTime(String timestamp) { if (timestamp == null || timestamp.length() < 16) return ""; return timestamp.substring(11, 16); }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
    }

    private String friendlyError(Throwable t) {
        Throwable x = t;
        while (x.getCause() != null) x = x.getCause();
        String m = x.getMessage();
        return m == null || m.trim().isEmpty() ? x.getClass().getSimpleName() : m;
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow(); scheduler.shutdownNow(); if (imageLoader != null) imageLoader.shutdown();
    }

    // Small FrameLayout wrapper because creating a full XML hierarchy just for two stacked avatars is unnecessary.
    private static final class FrameLayoutWrap extends android.widget.FrameLayout {
        FrameLayoutWrap(Context c) { super(c); }
        void add(View v, ViewGroup.LayoutParams lp) { addView(v, lp); }
    }
}
