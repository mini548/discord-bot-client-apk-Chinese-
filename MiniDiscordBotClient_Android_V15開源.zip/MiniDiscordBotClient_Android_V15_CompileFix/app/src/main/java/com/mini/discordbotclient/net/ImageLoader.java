package com.mini.discordbotclient.net;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small dependency-free image loader for Code on the Go / offline-friendly builds.
 * Memory cache + disk cache + in-flight request coalescing + bitmap downsampling.
 */
public final class ImageLoader {
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(32 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return Math.max(1, value.getByteCount() / 1024);
        }
    };

    private final File diskDir;
    private final Map<String, CopyOnWriteArrayList<WeakReference<ImageView>>> waiters = new ConcurrentHashMap<>();
    private final Map<String, Boolean> inFlight = new ConcurrentHashMap<>();
    // Dedicated image workers prevent avatar/emoji downloads from blocking Discord API requests.
    private final ExecutorService imageExecutor = Executors.newFixedThreadPool(8);
    private final ExecutorService diskExecutor = Executors.newSingleThreadExecutor();

    public ImageLoader(android.content.Context context) {
        diskDir = new File(context.getCacheDir(), "discord-image-cache");
        //noinspection ResultOfMethodCallIgnored
        diskDir.mkdirs();
    }

    /** Memory-only lookup. Safe to call from the UI thread. */
    public Bitmap getCached(String url) {
        if (url == null || url.isEmpty()) return null;
        Bitmap hit = memory.get(url);
        return hit != null && !hit.isRecycled() ? hit : null;
    }

    public void preload(final String url, final ExecutorService io) {
        if (url == null || url.isEmpty() || io == null) return;
        if (getCached(url) != null) return;
        if (inFlight.putIfAbsent(url, Boolean.TRUE) != null) return;
        imageExecutor.execute(() -> {
            try {
                Bitmap b = readDisk(url, 128);
                if (b == null) b = fetch(url, 128, 128);
                if (b != null) put(url, b);
            } finally {
                inFlight.remove(url);
            }
        });
    }

    /** Blocking fetch for rich-text emoji/background preparation. Call off the UI thread. */
    public Bitmap loadSync(final String url, int targetPx) {
        if (url == null || url.isEmpty()) return null;
        Bitmap hit = memory.get(url);
        if (hit != null && !hit.isRecycled()) return hit;
        Bitmap disk = readDisk(url, targetPx);
        if (disk != null) { memory.put(url, disk); return disk; }
        Bitmap b = fetch(url, targetPx, targetPx);
        if (b != null) put(url, b);
        return b;
    }

    public void load(final String url, final ImageView target, final Bitmap placeholder, final ExecutorService io) {
        if (target == null) return;
        target.setImageBitmap(placeholder);
        target.setTag(url);
        target.setVisibility(ImageView.INVISIBLE);
        if (url == null || url.isEmpty() || io == null) return;

        Bitmap hit = memory.get(url);
        if (hit != null && !hit.isRecycled()) {
            target.setImageBitmap(hit);
            target.setVisibility(ImageView.VISIBLE);
            return;
        }

        waiters.computeIfAbsent(url, k -> new CopyOnWriteArrayList<>())
                .add(new WeakReference<>(target));

        if (inFlight.putIfAbsent(url, Boolean.TRUE) == null) {
            imageExecutor.execute(() -> {
                Bitmap b = null;
                try {
                    int w = Math.max(64, target.getWidth());
                    int h = Math.max(64, target.getHeight());
                    b = fetch(url, w, h);
                    if (b == null) b = readDisk(url, Math.max(w, h));
                    if (b != null) put(url, b);
                } finally {
                    inFlight.remove(url);
                    dispatch(url, b);
                }
            });
        }
    }

    private void dispatch(String url, Bitmap bitmap) {
        CopyOnWriteArrayList<WeakReference<ImageView>> list = waiters.remove(url);
        if (list == null) return;
        for (WeakReference<ImageView> ref : list) {
            ImageView v = ref.get();
            if (v == null) continue;
            v.post(() -> {
                Object tag = v.getTag();
                if (!url.equals(tag)) return;
                if (bitmap != null && !bitmap.isRecycled()) {
                    v.setImageBitmap(bitmap);
                    v.setVisibility(ImageView.VISIBLE);
                } else {
                    // Reveal the initials/fallback view underneath when the CDN is unavailable.
                    v.setVisibility(ImageView.INVISIBLE);
                }
            });
        }
    }

    private void put(String url, Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return;
        memory.put(url, bitmap);
        // Disk persistence is intentionally deferred; the UI should receive the bitmap first.
        final Bitmap persist = bitmap;
        diskExecutor.execute(() -> writeDisk(url, persist));
    }

    private Bitmap fetch(String url, int reqW, int reqH) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(2500);
            c.setReadTimeout(7000);
            c.setUseCaches(true);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "MiniDiscordBotClient/4.0 Android");
            c.setRequestProperty("Accept", "image/avif,image/webp,image/png,image/jpeg,image/gif;q=0.8,*/*;q=0.5");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) return null;
            try (InputStream in = new BufferedInputStream(c.getInputStream())) {
                byte[] bytes = readLimited(in, 4 * 1024 * 1024);
                if (bytes == null || bytes.length == 0) return null;
                return decodeDownsampled(bytes, reqW, reqH);
            }
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] readLimited(InputStream in, int maxBytes) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024]; int total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maxBytes) return null;
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static Bitmap decodeDownsampled(byte[] data, int reqW, int reqH) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        int sample = 1;
        int tw = Math.max(1, reqW), th = Math.max(1, reqH);
        while ((bounds.outWidth / sample) > tw * 2 || (bounds.outHeight / sample) > th * 2) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
    }

    private Bitmap readDisk(String url, int targetPx) {
        File f = new File(diskDir, key(url) + ".bin");
        if (!f.isFile() || f.length() <= 0 || f.length() > 4 * 1024 * 1024) return null;
        try (FileInputStream in = new FileInputStream(f);
             BufferedInputStream bin = new BufferedInputStream(in)) {
            byte[] data = readLimited(bin, 4 * 1024 * 1024);
            if (data == null) return null;
            Bitmap b = decodeDownsampled(data, targetPx, targetPx);
            if (b != null) return b;
        } catch (Throwable ignored) { }
        return null;
    }

    private void writeDisk(String url, Bitmap bitmap) {
        File f = new File(diskDir, key(url) + ".bin");
        if (f.isFile() && f.length() > 0) return;
        File tmp = new File(diskDir, key(url) + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp);
             BufferedOutputStream bout = new BufferedOutputStream(out)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, bout);
            bout.flush();
        } catch (Throwable ignored) {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            return;
        }
        //noinspection ResultOfMethodCallIgnored
        tmp.renameTo(f);
        trimDiskCache();
    }

    private void trimDiskCache() {
        File[] files = diskDir.listFiles();
        if (files == null || files.length <= 128) return;
        List<File> list = new ArrayList<>();
        for (File f : files) if (f.getName().endsWith(".bin")) list.add(f);
        list.sort((a, b) -> Long.compare(a.lastModified(), b.lastModified()));
        int remove = Math.max(0, list.size() - 96);
        for (int i = 0; i < remove; i++) {
            //noinspection ResultOfMethodCallIgnored
            list.get(i).delete();
        }
    }

    public void shutdown() {
        imageExecutor.shutdownNow();
        diskExecutor.shutdownNow();
        waiters.clear();
        inFlight.clear();
    }

    private static String key(String url) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(url.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(url.hashCode());
        }
    }
}
