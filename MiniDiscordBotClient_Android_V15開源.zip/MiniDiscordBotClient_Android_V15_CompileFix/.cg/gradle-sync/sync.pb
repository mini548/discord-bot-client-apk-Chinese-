
1H/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix1790338798881"�
app/build.gradleY/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix/app/build.gradle� �č��4*@51c67128b2688ae4d84223577695033b0c837796c1a26dbbb6af8609e73c8d34"�
build.gradleU/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix/build.gradle� ��޵�4*@e19cdfeba9f331ebc645ef9eac5634326d6ba2fbf28cbd133d5fe9bd2dcdd66c"�
gradle.propertiesZ/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix/gradle.properties� �č��4*@52841fcd7bacdc3e3b307a301b2b2c9ab310531ee4c3bd2f75f225df33522531"�
settings.gradleX/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix/settings.gradle� ��޵�4*@98ebff7906889d4eeb9e4412b84f70f5486ffd69c511384bc171b8ce99f214ce*�
c/storage/emulated/0/Download/MiniDiscordBotClient_Android_V15_CompileFix/.cg/gradle-sync/project.pb@24c1ef99903715ec4264edcffcc6dbf35936f18a32629822fa37f0aec8273c1e