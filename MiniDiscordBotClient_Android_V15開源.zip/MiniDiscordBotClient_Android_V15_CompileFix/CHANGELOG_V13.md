# V13 UI Layer / Typography Fix

- Reworked channel/category rows to use wrap-content heights instead of fixed heights that clipped multi-line text.
- Disabled clipping on channel pane, channel list, rows, and message body containers where overlapping/rich content can occur.
- Promoted channel text labels with `bringToFront()` so text is rendered above decorative/background layers.
- Channel names now support up to two natural lines with safe END ellipsis instead of being vertically cut in half.
- Removed forced single-line layout behavior that caused long mixed Chinese/Latin channel names to disappear or overlap.
- Chat title and message content now explicitly use natural wrapping and non-clipping containers.
- Preserved Discord mention and custom emoji rendering from V12.


V14 performance: dedicated 6-thread image pool, 24MB bitmap cache, deferred disk persistence, fewer avatar preloads, non-blocking rich emoji rendering, and 3-second message polling.
